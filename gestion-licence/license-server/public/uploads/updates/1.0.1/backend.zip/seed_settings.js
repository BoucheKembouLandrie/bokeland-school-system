"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const SchoolSettings_1 = __importDefault(require("./models/SchoolSettings"));
const run = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log("Connected to DB.");
        await SchoolSettings_1.default.destroy({ where: {} });
        console.log("Cleared existing settings.");
        const settings = await SchoolSettings_1.default.create({
            school_name: "Test School Manual",
            email: "manual@test.com",
            phone: "690000000",
            country_code: "+237",
            country: "CM",
            address: "Yaounde",
            language: "fr",
            date_format: "DD-MM-YYYY",
            is_onboarding_complete: true, // Bypass onboarding
            license_status: 'TRIAL',
            license_check_date: new Date()
        });
        console.log("Created Settings:", settings.toJSON());
    }
    catch (error) {
        console.error("Error seeding settings:", error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
