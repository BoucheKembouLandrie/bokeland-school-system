"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const ExpenseControllerVerified_1 = require("../controllers/ExpenseControllerVerified");
const router = express_1.default.Router();
router.get('/', ExpenseControllerVerified_1.getAllExpenses);
router.post('/', ExpenseControllerVerified_1.createExpense);
router.put('/:id', ExpenseControllerVerified_1.updateExpense);
router.delete('/:id', ExpenseControllerVerified_1.deleteExpense);
exports.default = router;
