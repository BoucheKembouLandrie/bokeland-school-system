"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCategory = exports.updateCategory = exports.createCategory = exports.getAllCategories = void 0;
const SubjectCategory_1 = __importDefault(require("../models/SubjectCategory"));
const Subject_1 = __importDefault(require("../models/Subject"));
const getAllCategories = async (req, res) => {
    try {
        const categories = await SubjectCategory_1.default.findAll({ order: [['nom', 'ASC']] });
        res.json(categories);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllCategories = getAllCategories;
const createCategory = async (req, res) => {
    try {
        const { nom } = req.body;
        if (!nom || !nom.trim()) {
            return res.status(400).json({ message: 'Le nom de la catégorie est requis.' });
        }
        const category = await SubjectCategory_1.default.create({ nom: nom.trim() });
        res.status(201).json(category);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createCategory = createCategory;
const updateCategory = async (req, res) => {
    try {
        const category = await SubjectCategory_1.default.findByPk(req.params.id);
        if (!category)
            return res.status(404).json({ message: 'Catégorie non trouvée.' });
        const { nom } = req.body;
        if (!nom || !nom.trim()) {
            return res.status(400).json({ message: 'Le nom de la catégorie est requis.' });
        }
        await category.update({ nom: nom.trim() });
        res.json(category);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateCategory = updateCategory;
const deleteCategory = async (req, res) => {
    try {
        const category = await SubjectCategory_1.default.findByPk(req.params.id);
        if (!category)
            return res.status(404).json({ message: 'Catégorie non trouvée.' });
        // Check if any subject uses this category
        const usageCount = await Subject_1.default.count({ where: { category_id: req.params.id } });
        if (usageCount > 0) {
            return res.status(409).json({
                message: `Cette catégorie est assignée à ${usageCount} matière(s) et ne peut pas être supprimée.`
            });
        }
        await category.destroy();
        res.json({ message: 'Catégorie supprimée.' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteCategory = deleteCategory;
