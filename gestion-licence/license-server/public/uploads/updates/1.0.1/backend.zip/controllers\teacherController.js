"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transferTeachers = exports.deleteTeacher = exports.updateTeacher = exports.createTeacher = exports.getTeacherById = exports.getAllTeachers = void 0;
const Teacher_1 = __importDefault(require("../models/Teacher"));
const Subject_1 = __importDefault(require("../models/Subject"));
const getAllTeachers = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const teachers = await Teacher_1.default.findAll({
            where: { school_year_id: schoolYearId },
            include: [{ model: Subject_1.default, as: 'subjects' }]
        });
        res.json(teachers);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllTeachers = getAllTeachers;
const getTeacherById = async (req, res) => {
    try {
        const teacher = await Teacher_1.default.findByPk(req.params.id, { include: [{ model: Subject_1.default, as: 'subjects' }] });
        if (!teacher)
            return res.status(404).json({ message: 'Teacher not found' });
        res.json(teacher);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getTeacherById = getTeacherById;
const createTeacher = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const teacher = await Teacher_1.default.create({
            ...req.body,
            school_year_id: schoolYearId
        });
        res.status(201).json(teacher);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createTeacher = createTeacher;
const updateTeacher = async (req, res) => {
    try {
        const teacher = await Teacher_1.default.findByPk(req.params.id);
        if (!teacher)
            return res.status(404).json({ message: 'Teacher not found' });
        await teacher.update(req.body);
        res.json(teacher);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateTeacher = updateTeacher;
const deleteTeacher = async (req, res) => {
    try {
        const teacher = await Teacher_1.default.findByPk(req.params.id);
        if (!teacher)
            return res.status(404).json({ message: 'Teacher not found' });
        await teacher.destroy();
        res.json({ message: 'Teacher deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteTeacher = deleteTeacher;
const transferTeachers = async (req, res) => {
    try {
        const { teacherIds, destYearId } = req.body;
        if (!teacherIds || !Array.isArray(teacherIds) || !destYearId) {
            return res.status(400).json({ message: 'Invalid payload' });
        }
        let transferCount = 0;
        for (const teacherId of teacherIds) {
            const sourceTeacher = await Teacher_1.default.findByPk(teacherId);
            if (sourceTeacher) {
                await Teacher_1.default.create({
                    nom: sourceTeacher.nom,
                    prenom: sourceTeacher.prenom,
                    tel: sourceTeacher.tel,
                    email: sourceTeacher.email,
                    salaire: sourceTeacher.salaire,
                    school_year_id: destYearId
                });
                transferCount++;
            }
        }
        res.json({ message: 'Transfer successful', count: transferCount });
    }
    catch (error) {
        console.error('Transfer error:', error);
        res.status(500).json({ message: 'Server error during transfer', error });
    }
};
exports.transferTeachers = transferTeachers;
