"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const morgan_1 = __importDefault(require("morgan"));
const app = (0, express_1.default)();
// Middleware
app.use((0, cors_1.default)({
    origin: true, // Allow any origin
    credentials: true
}));
// app.use(helmet({
//     crossOriginResourcePolicy: { policy: "cross-origin" },
// }));
app.use((0, morgan_1.default)('dev'));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// Debug Middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url}`);
    // Log to file
    const fs = require('fs');
    const path = require('path');
    const logPath = path.join(__dirname, '../request_monitor.log');
    const logEntry = `${timestamp} - ${req.method} ${req.url} - Headers: ${JSON.stringify(req.headers)}\n`;
    try {
        fs.appendFileSync(logPath, logEntry, 'utf8');
    }
    catch (e) {
        // ignore logging error
    }
    next();
});
const licenseMiddleware_1 = require("./middleware/licenseMiddleware");
const licenseRoutes_1 = __importDefault(require("./routes/licenseRoutes"));
// Initialize Update Check on Startup - MOVED TO SERVER.TS
// Initialize License Check on Startup - MOVED TO SERVER.TS
// checkLicense(true).then(status => {
//     console.log('--- LICENSE STATUS ---');
//     console.log(status);
//     console.log('----------------------');
// });
// Apply License Middleware globally (it will skip its own routes internally)
app.use(licenseMiddleware_1.licenseMiddleware);
app.use('/api/license', licenseRoutes_1.default);
// Direct Debug Route
app.get('/api/schedules-direct', (req, res) => {
    res.json({ message: 'Direct route working' });
});
// DIRECT ROUTE IMPLEMENTATION TO FIX 404
const Schedule_1 = __importDefault(require("./models/Schedule"));
const Subject_1 = __importDefault(require("./models/Subject"));
const Teacher_1 = __importDefault(require("./models/Teacher"));
app.post('/api/schedules', async (req, res) => {
    console.log('DIRECT POST /api/schedules HIT');
    try {
        const { classe_id, subject_id, day_of_week, start_time, end_time } = req.body;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        console.log('Creating schedule with:', req.body);
        const schedule = await Schedule_1.default.create({
            classe_id,
            subject_id,
            day_of_week,
            start_time,
            end_time,
            school_year_id: schoolYearId
        });
        console.log('Schedule created ID:', schedule.id);
        res.status(201).json(schedule);
    }
    catch (error) {
        console.error('Error in direct schedule creation:', error);
        res.status(500).json({ message: 'Server error', error });
    }
});
app.get('/api/schedules/class/:classId', async (req, res) => {
    console.log('DIRECT GET /api/schedules/class/:classId HIT');
    try {
        const { classId } = req.params;
        const schoolYearId = req.headers['x-school-year-id'];
        const schedules = await Schedule_1.default.findAll({
            where: {
                classe_id: classId,
                school_year_id: schoolYearId
            },
            include: [{
                    model: Subject_1.default,
                    as: 'subject',
                    include: [{
                            model: Teacher_1.default,
                            as: 'teacher',
                            attributes: ['id', 'nom', 'prenom']
                        }]
                }],
            order: [['day_of_week', 'ASC'], ['start_time', 'ASC']]
        });
        res.json(schedules);
    }
    catch (error) {
        console.error('Error fetching schedules:', error);
        res.status(500).json({ message: 'Server error', error });
    }
});
// END DIRECT ROUTE
const authRoutes_1 = __importDefault(require("./routes/authRoutes"));
const studentRoutes_1 = __importDefault(require("./routes/studentRoutes"));
const classRoutes_1 = __importDefault(require("./routes/classRoutes"));
const teacherRoutes_1 = __importDefault(require("./routes/teacherRoutes"));
const subjectRoutes_1 = __importDefault(require("./routes/subjectRoutes"));
const subjectCategoryRoutes_1 = __importDefault(require("./routes/subjectCategoryRoutes"));
const gradeRoutes_1 = __importDefault(require("./routes/gradeRoutes"));
const paymentRoutes_1 = __importDefault(require("./routes/paymentRoutes"));
const attendanceRoutes_1 = __importDefault(require("./routes/attendanceRoutes"));
const settingsRoutes_1 = __importDefault(require("./routes/settingsRoutes"));
const usersRoutes_1 = __importDefault(require("./routes/usersRoutes"));
const evaluationRoutes_1 = __importDefault(require("./routes/evaluationRoutes"));
const staffRoutes_1 = __importDefault(require("./routes/staffRoutes"));
const ExpenseRoutesVerified_1 = __importDefault(require("./routes/ExpenseRoutesVerified"));
const suggestionRoutes_1 = __importDefault(require("./routes/suggestionRoutes"));
const dataRoutes_1 = __importDefault(require("./routes/dataRoutes"));
const schoolYearRoutes_1 = __importDefault(require("./routes/schoolYearRoutes"));
const scheduleRoutes_1 = __importDefault(require("./routes/scheduleRoutes"));
const onboardingRoutes_1 = __importDefault(require("./routes/onboardingRoutes"));
const updateRoutes_1 = __importDefault(require("./routes/updateRoutes"));
console.log('Finished importing routes in app.ts');
const path_1 = __importDefault(require("path"));
app.use('/api/auth', authRoutes_1.default);
app.use('/api/students', studentRoutes_1.default);
app.use('/api/classes', classRoutes_1.default);
app.use('/api/teachers', teacherRoutes_1.default);
app.use('/api/subjects', subjectRoutes_1.default);
app.use('/api/subject-categories', subjectCategoryRoutes_1.default);
app.use('/api/grades', gradeRoutes_1.default);
app.use('/api/notes', gradeRoutes_1.default); // Alias for frontend compatibility
app.use('/api/payments', paymentRoutes_1.default);
app.use('/api/attendance', attendanceRoutes_1.default);
app.use('/api/settings', settingsRoutes_1.default);
app.use('/api/users', usersRoutes_1.default);
app.use('/api/evaluations', evaluationRoutes_1.default);
app.use('/api/staff', staffRoutes_1.default);
app.use('/api/expenses', ExpenseRoutesVerified_1.default);
app.use('/api/suggestions', suggestionRoutes_1.default);
app.use('/api/data', dataRoutes_1.default);
app.use('/api/onboarding', onboardingRoutes_1.default);
app.use('/api/update', updateRoutes_1.default);
const examRuleRoutes_1 = __importDefault(require("./routes/examRuleRoutes"));
// ... existing routes ...
app.use('/api/school-years', schoolYearRoutes_1.default);
app.use('/api/exam-rules', examRuleRoutes_1.default);
// END DIRECT ROUTE
console.log('Registering /api/schedules routes (original)...');
app.use('/api/schedules', scheduleRoutes_1.default);
// Serve uploaded files statically
const uploadsPath = path_1.default.join(__dirname, '../uploads');
console.log('Serving static files from:', uploadsPath);
app.use('/uploads', express_1.default.static(uploadsPath));
// Health Check
app.get('/', (req, res) => {
    res.send('Leuana School API is running');
});
// Global Error Handler
app.use((err, req, res, next) => {
    console.error('GLOBAL ERROR:', err);
    const fs = require('fs');
    const path = require('path');
    const logPath = path.join(__dirname, '../backend_error.log');
    const timestamp = new Date().toISOString();
    fs.appendFileSync(logPath, `[${timestamp}] ${err.stack || err.message}\n`);
    if (!res.headersSent) {
        res.status(500).json({ message: 'Internal Server Error', error: err.message });
    }
});
app.get('/api/debug-db', async (req, res) => {
    const sequelize = require('./config/database').default;
    res.json({
        db_name: sequelize.config.database,
        db_host: sequelize.config.host,
        db_port: sequelize.config.port
    });
});
exports.default = app;
