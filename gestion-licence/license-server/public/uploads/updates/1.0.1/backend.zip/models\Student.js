"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
const Class_1 = __importDefault(require("./Class"));
class Student extends sequelize_1.Model {
}
Student.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    matricule: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    nom: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    prenom: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    date_naissance: {
        type: sequelize_1.DataTypes.DATEONLY,
        allowNull: false,
    },
    sexe: {
        type: sequelize_1.DataTypes.ENUM('M', 'F'),
        allowNull: false,
    },
    adresse: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    parent_tel: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    classe_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Class_1.default,
            key: 'id',
        },
    },
    date_inscription: {
        type: sequelize_1.DataTypes.DATE,
        defaultValue: sequelize_1.DataTypes.NOW,
    },
    category: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
        defaultValue: 'Non redoublant(e)',
    },
    school_year_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'school_years',
            key: 'id',
        },
    },
}, {
    sequelize: database_1.default,
    tableName: 'students',
});
exports.default = Student;
