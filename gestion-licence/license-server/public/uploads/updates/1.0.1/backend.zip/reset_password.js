"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const User_1 = __importDefault(require("./models/User"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const run = async () => {
    try {
        await models_1.sequelize.authenticate();
        const user = await User_1.default.findOne({ where: { role: 'admin' } });
        if (user) {
            const hashedPassword = await bcrypt_1.default.hash('Admin@123', 10);
            await user.update({ password: hashedPassword });
            console.log("Password reset for admin.");
        }
        else {
            console.log("Admin user not found.");
        }
    }
    catch (error) {
        console.error(error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
