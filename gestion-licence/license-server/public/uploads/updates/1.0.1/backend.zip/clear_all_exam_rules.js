"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const ExamRule_1 = __importDefault(require("./models/ExamRule"));
const clearAll = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        // Delete ALL rules (all years)
        const count = await ExamRule_1.default.destroy({ where: {} });
        console.log(`✅ Deleted ${count} rules (all years)`);
    }
    catch (e) {
        console.error('❌ ERROR:', e.message);
    }
    finally {
        await models_1.sequelize.close();
    }
};
clearAll();
