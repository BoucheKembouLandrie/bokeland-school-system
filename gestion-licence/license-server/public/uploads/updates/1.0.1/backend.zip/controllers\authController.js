"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPassword = exports.register = exports.getMe = exports.login = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const User_1 = __importDefault(require("../models/User"));
const emailService_1 = require("../services/emailService");
const licenseService_1 = require("../services/licenseService");
const login = async (req, res) => {
    try {
        // --- LICENSE CHECK START ---
        let licenseStatus = (0, licenseService_1.getCachedLicenseStatus)();
        if (!licenseStatus) {
            licenseStatus = await (0, licenseService_1.checkLicense)();
        }
        if (licenseStatus && (licenseStatus.status === 'EXPIRED' || licenseStatus.status === 'BANNED')) {
            return res.status(403).json({
                message: 'Accès bloqué : Abonnement expiré ou compte suspendu. Veuillez contacter le support.',
                code: 'LICENSE_BLOCKED'
            });
        }
        // --- LICENSE CHECK END ---
        const { username, password } = req.body;
        const user = await User_1.default.findOne({ where: { username } });
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        const isMatch = await bcrypt_1.default.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        const token = jsonwebtoken_1.default.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'your_jwt_secret', { expiresIn: '1d' });
        res.json({
            token,
            user: {
                id: user.id,
                username: user.username,
                role: user.role,
                is_default: user.is_default,
                teacher_id: user.teacher_id,
                permissions: user.permissions
            }
        });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.login = login;
const getMe = async (req, res) => {
    try {
        const user = await User_1.default.findByPk(req.user.id, { attributes: { exclude: ['password'] } });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(user);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getMe = getMe;
const register = async (req, res) => {
    try {
        const { username, password, role } = req.body;
        const hashedPassword = await bcrypt_1.default.hash(password, 10);
        const user = await User_1.default.create({ username, password: hashedPassword, role });
        res.status(201).json({ message: 'User created successfully', user: { id: user.id, username: user.username, role: user.role } });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.register = register;
const forgotPassword = async (req, res) => {
    try {
        const { email, role } = req.body;
        // Validate email
        if (!email || !email.includes('@')) {
            return res.status(400).json({ message: 'Adresse email invalide' });
        }
        // Only process for admin role
        if (role !== 'admin') {
            return res.status(400).json({ message: 'Cette fonctionnalité est réservée aux administrateurs' });
        }
        // Find admin user with this email
        const user = await User_1.default.findOne({
            where: {
                email: email,
                role: 'admin'
            }
        });
        if (!user) {
            return res.status(404).json({
                message: 'Aucun compte administrateur n\'est associé à cette adresse email'
            });
        }
        // Generate temporary password (8 characters: letters and numbers)
        const generateTempPassword = () => {
            const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
            let password = '';
            for (let i = 0; i < 8; i++) {
                password += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return password;
        };
        const temporaryPassword = generateTempPassword();
        // Hash the temporary password
        const hashedPassword = await bcrypt_1.default.hash(temporaryPassword, 10);
        // Update user password
        await user.update({ password: hashedPassword });
        // Send email with credentials
        await (0, emailService_1.sendPasswordRecoveryEmail)(email, user.username, temporaryPassword);
        res.json({
            message: 'Un email contenant vos identifiants a été envoyé à votre adresse email'
        });
    }
    catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({
            message: 'Erreur lors de l\'envoi de l\'email. Veuillez réessayer plus tard.'
        });
    }
};
exports.forgotPassword = forgotPassword;
