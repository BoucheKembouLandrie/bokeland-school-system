"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const scheduleController_1 = require("../controllers/scheduleController");
const authMiddleware_1 = require("../middlewares/authMiddleware");
console.log('Loading scheduleRoutes...');
const router = (0, express_1.Router)();
router.get('/test', (req, res) => {
    console.log('GET /api/schedules/test hit');
    res.json({ message: 'Schedule routes working' });
});
router.use(authMiddleware_1.authenticateToken);
router.get('/', scheduleController_1.getAllSchedules);
router.get('/class/:classId', scheduleController_1.getSchedulesByClass);
router.post('/', scheduleController_1.createSchedule);
router.put('/:id', scheduleController_1.updateSchedule);
router.delete('/:id', scheduleController_1.deleteSchedule);
exports.default = router;
