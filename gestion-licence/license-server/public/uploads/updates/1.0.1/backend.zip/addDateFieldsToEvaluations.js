"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
const addDateFieldsToEvaluations = async () => {
    try {
        const queryInterface = database_1.default.getQueryInterface();
        console.log('Checking evaluations table columns...');
        const tableDescription = await queryInterface.describeTable('evaluations');
        console.log('Current columns:', Object.keys(tableDescription));
        // Add date_debut column
        if (!tableDescription.date_debut) {
            console.log('Adding date_debut column...');
            await queryInterface.addColumn('evaluations', 'date_debut', {
                type: sequelize_1.DataTypes.DATEONLY,
                allowNull: true,
            });
            console.log('✓ Column "date_debut" added');
        }
        else {
            console.log('✓ Column "date_debut" already exists');
        }
        // Add date_fin column
        if (!tableDescription.date_fin) {
            console.log('Adding date_fin column...');
            await queryInterface.addColumn('evaluations', 'date_fin', {
                type: sequelize_1.DataTypes.DATEONLY,
                allowNull: true,
            });
            console.log('✓ Column "date_fin" added');
        }
        else {
            console.log('✓ Column "date_fin" already exists');
        }
        console.log('\n✅ Migration completed successfully!');
    }
    catch (error) {
        console.error('❌ Error during migration:', error);
    }
    finally {
        await database_1.default.close();
    }
};
addDateFieldsToEvaluations();
