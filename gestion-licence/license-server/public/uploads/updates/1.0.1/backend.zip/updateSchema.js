"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const syncSchema = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Database connected.');
        // Use alter: true to add the new columns without dropping data
        await models_1.sequelize.sync({ alter: true });
        console.log('Schema synchronized successfully.');
    }
    catch (error) {
        console.error('Error syncing schema:', error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
syncSchema();
