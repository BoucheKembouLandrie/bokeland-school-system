"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const SchoolYear_1 = __importDefault(require("./models/SchoolYear"));
const fixExamRules = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        // Get default/active year
        const year = await SchoolYear_1.default.findOne({ where: { is_active: true } }) || await SchoolYear_1.default.findOne();
        if (!year) {
            console.log('No school year found. Cannot migrate rules.');
            return;
        }
        console.log(`Assigning orphaned rules to year: ${year.name} (ID: ${year.id})`);
        const [results, metadata] = await models_1.sequelize.query(`UPDATE exam_rules SET school_year_id = ${year.id} WHERE school_year_id IS NULL`);
        console.log('Update result:', metadata);
        console.log('Done.');
    }
    catch (error) {
        console.error('Error:', error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
fixExamRules();
