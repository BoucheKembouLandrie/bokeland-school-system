"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Schedule_1 = __importDefault(require("./models/Schedule"));
async function createSchedulesTable() {
    try {
        console.log('Creating schedules table...');
        await Schedule_1.default.sync({ force: false });
        console.log('✅ Schedules table created successfully!');
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Error creating schedules table:', error);
        process.exit(1);
    }
}
createSchedulesTable();
