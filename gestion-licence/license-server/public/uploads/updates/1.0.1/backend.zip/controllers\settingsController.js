"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadLogo = exports.updateSettings = exports.getSettings = void 0;
const models_1 = require("../models");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
// Forced update
const getSettings = async (req, res) => {
    try {
        let settings = await models_1.SchoolSettings.findOne();
        if (!settings) {
            settings = await models_1.SchoolSettings.create({
                school_name: 'Bokeland School System',
                website: '',
                address: '',
                phone: '',
                logo_url: ''
            });
        }
        res.json(settings);
    }
    catch (error) {
        res.status(500).json({ message: 'Error fetching settings', error });
    }
};
exports.getSettings = getSettings;
const updateSettings = async (req, res) => {
    try {
        const { school_name, website, address, phone, email, country_code, date_format } = req.body;
        let settings = await models_1.SchoolSettings.findOne();
        if (!settings) {
            settings = await models_1.SchoolSettings.create(req.body);
        }
        else {
            await settings.update({ school_name, website, address, phone, email, country_code, date_format });
        }
        res.json(settings);
    }
    catch (error) {
        res.status(500).json({ message: 'Error updating settings', error });
    }
};
exports.updateSettings = updateSettings;
const uploadLogo = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }
        const logoUrl = `/uploads/${req.file.filename}`;
        let settings = await models_1.SchoolSettings.findOne();
        if (!settings) {
            settings = await models_1.SchoolSettings.create({ logo_url: logoUrl });
        }
        else {
            // Optional: Delete old logo if exists
            // Delete old logo if exists
            if (settings.logo_url) {
                // Remove leading slash if present to ensure path.join treats it as relative
                const relativePath = settings.logo_url.startsWith('/') ? settings.logo_url.substring(1) : settings.logo_url;
                const oldPath = path_1.default.join(__dirname, '../../', relativePath);
                console.log('Attempting to delete old logo at:', oldPath);
                if (fs_1.default.existsSync(oldPath)) {
                    try {
                        fs_1.default.unlinkSync(oldPath);
                        console.log('Old logo deleted successfully');
                    }
                    catch (err) {
                        console.error('Error deleting old logo:', err);
                    }
                }
                else {
                    console.log('Old logo file not found at:', oldPath);
                }
            }
            await settings.update({ logo_url: logoUrl });
        }
        res.json({ logo_url: logoUrl });
    }
    catch (error) {
        res.status(500).json({ message: 'Error uploading logo', error });
    }
};
exports.uploadLogo = uploadLogo;
