"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendSuggestion = void 0;
const nodemailer_1 = __importDefault(require("nodemailer"));
const sendSuggestion = async (req, res) => {
    try {
        const { name, email, message } = req.body;
        // Validate input
        if (!name || !email || !message) {
            return res.status(400).json({ error: 'Tous les champs sont requis' });
        }
        // Create transporter using environment variables
        const transporter = nodemailer_1.default.createTransport({
            host: process.env.SMTP_HOST,
            port: parseInt(process.env.SMTP_PORT || '465'),
            secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASSWORD
            },
            tls: {
                rejectUnauthorized: false
            }
        });
        // Email options
        const mailOptions = {
            from: process.env.EMAIL_FROM || process.env.EMAIL_USER, // Use the configured sender
            to: 'client-form@bokeland.com', // Keep this or make it configurable if needed
            subject: 'boite à suggestion du logiciel scolaire',
            text: `Nom: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
            html: `
                <h3>Nouvelle suggestion - Logiciel Scolaire</h3>
                <p><strong>Nom:</strong> ${name}</p>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Message:</strong></p>
                <p>${message.replace(/\n/g, '<br>')}</p>
            `
        };
        // Send email
        await transporter.sendMail(mailOptions);
        res.status(200).json({ message: 'Suggestion envoyée avec succès' });
    }
    catch (error) {
        console.error('Error sending suggestion:', error);
        res.status(500).json({ error: 'Erreur lors de l\'envoi de la suggestion' });
    }
};
exports.sendSuggestion = sendSuggestion;
