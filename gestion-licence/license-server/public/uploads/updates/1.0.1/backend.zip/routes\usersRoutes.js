"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const usersController_1 = require("../controllers/usersController");
const authMiddleware_1 = require("../middlewares/authMiddleware");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(authMiddleware_1.authenticateToken);
// User management routes (admin only - add middleware check if needed)
router.get('/', usersController_1.getAllUsers);
router.post('/', usersController_1.createUser);
router.put('/:id', usersController_1.updateUser);
router.delete('/:id', usersController_1.deleteUser);
exports.default = router;
