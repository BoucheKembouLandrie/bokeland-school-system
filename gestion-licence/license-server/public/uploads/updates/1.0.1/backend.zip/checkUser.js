"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const User_1 = __importDefault(require("./models/User"));
const checkUser = async () => {
    try {
        await database_1.default.sync();
        const admin = await User_1.default.findOne({ where: { username: 'admin' } });
        if (admin) {
            console.log('Admin user found:');
            console.log('ID:', admin.id);
            console.log('Username:', admin.username);
            console.log('Role:', admin.role);
            console.log('Is Default:', admin.is_default);
            console.log('Teacher ID:', admin.teacher_id);
            console.log('Permissions:', admin.permissions);
        }
        else {
            console.log('No admin user found');
        }
    }
    catch (error) {
        console.error('Error:', error);
    }
    finally {
        await database_1.default.close();
    }
};
checkUser();
