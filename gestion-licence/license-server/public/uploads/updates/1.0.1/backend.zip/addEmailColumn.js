"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
async function addEmailColumn() {
    try {
        await models_1.sequelize.authenticate();
        console.log('Database connected.');
        await models_1.sequelize.getQueryInterface().addColumn('school_settings', 'email', {
            type: 'VARCHAR(255)',
            allowNull: true,
        });
        console.log('✅ Email column added successfully!');
        process.exit(0);
    }
    catch (error) {
        console.error('Error adding email column:', error);
        process.exit(1);
    }
}
addEmailColumn();
