"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
async function addEmailToUsers() {
    try {
        console.log('Adding email column to users table...');
        await database_1.default.getQueryInterface().addColumn('users', 'email', {
            type: sequelize_1.DataTypes.STRING,
            allowNull: true,
        });
        console.log('Email column added successfully!');
        process.exit(0);
    }
    catch (error) {
        console.error('Error adding email column:', error);
        process.exit(1);
    }
}
addEmailToUsers();
