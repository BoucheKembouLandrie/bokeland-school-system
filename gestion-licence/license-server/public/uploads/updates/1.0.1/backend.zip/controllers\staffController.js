"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transferStaff = exports.deleteStaff = exports.updateStaff = exports.createStaff = exports.getAllStaff = void 0;
const Staff_1 = __importDefault(require("../models/Staff"));
const getAllStaff = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        const whereClause = {};
        if (schoolYearId) {
            whereClause.school_year_id = schoolYearId;
        }
        const staff = await Staff_1.default.findAll({ where: whereClause });
        res.json(staff);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllStaff = getAllStaff;
const createStaff = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const staff = await Staff_1.default.create({
            ...req.body,
            school_year_id: schoolYearId
        });
        res.status(201).json(staff);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createStaff = createStaff;
const updateStaff = async (req, res) => {
    try {
        const staff = await Staff_1.default.findByPk(req.params.id);
        if (!staff)
            return res.status(404).json({ message: 'Staff not found' });
        await staff.update(req.body);
        res.json(staff);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateStaff = updateStaff;
const deleteStaff = async (req, res) => {
    try {
        const staff = await Staff_1.default.findByPk(req.params.id);
        if (!staff)
            return res.status(404).json({ message: 'Staff not found' });
        await staff.destroy();
        res.json({ message: 'Staff deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteStaff = deleteStaff;
const transferStaff = async (req, res) => {
    try {
        const { staffIds, destYearId } = req.body;
        if (!staffIds || !Array.isArray(staffIds) || !destYearId) {
            return res.status(400).json({ message: 'Invalid payload' });
        }
        let transferCount = 0;
        for (const staffId of staffIds) {
            const sourceStaff = await Staff_1.default.findByPk(staffId);
            if (sourceStaff) {
                await Staff_1.default.create({
                    titre: sourceStaff.titre,
                    nom: sourceStaff.nom,
                    prenom: sourceStaff.prenom,
                    tel: sourceStaff.tel,
                    email: sourceStaff.email,
                    salaire: sourceStaff.salaire,
                    school_year_id: destYearId
                });
                transferCount++;
            }
        }
        res.json({ message: 'Transfer successful', count: transferCount });
    }
    catch (error) {
        console.error('Transfer error:', error);
        res.status(500).json({ message: 'Server error during transfer', error });
    }
};
exports.transferStaff = transferStaff;
