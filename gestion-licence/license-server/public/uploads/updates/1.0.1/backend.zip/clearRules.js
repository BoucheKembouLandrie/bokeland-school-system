"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const ExamRule_1 = __importDefault(require("./models/ExamRule"));
const SchoolYear_1 = __importDefault(require("./models/SchoolYear"));
const clearRules = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        // Get active year
        const year = await SchoolYear_1.default.findOne({ where: { is_active: true } }) || await SchoolYear_1.default.findOne();
        if (!year) {
            console.log('No school year found.');
            return;
        }
        console.log(`Clearing rules for year: ${year.name} (ID: ${year.id})`);
        const count = await ExamRule_1.default.destroy({
            where: { school_year_id: year.id }
        });
        console.log(`Deleted ${count} rules.`);
    }
    catch (error) {
        console.error('Error:', error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
clearRules();
