"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const updateService_1 = require("../services/updateService");
const router = (0, express_1.Router)();
// Endpoint for frontend to check if an update is available or in progress
router.get('/status', (req, res) => {
    res.json((0, updateService_1.getUpdateStatus)());
});
// Endpoint for frontend to trigger the installation
router.post('/install', async (req, res) => {
    try {
        await (0, updateService_1.installUpdate)();
        res.json({ success: true, message: 'Update installed successfully. Restarting...' });
    }
    catch (error) {
        console.error('Failed to install update:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});
exports.default = router;
