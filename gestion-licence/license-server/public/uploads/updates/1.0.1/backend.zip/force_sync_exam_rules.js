"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const ExamRule_1 = __importDefault(require("./models/ExamRule"));
const forceSync = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        // Force recreate table
        await ExamRule_1.default.sync({ force: true });
        console.log('✅ Table exam_rules recreated');
        // Show structure
        const [results] = await models_1.sequelize.query("SHOW COLUMNS FROM exam_rules");
        console.log('\nTable structure:');
        console.log(results);
    }
    catch (e) {
        console.error('❌ ERROR:', e.message);
    }
    finally {
        await models_1.sequelize.close();
    }
};
forceSync();
