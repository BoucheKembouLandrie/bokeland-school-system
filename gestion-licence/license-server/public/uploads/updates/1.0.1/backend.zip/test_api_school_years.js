"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
const run = async () => {
    try {
        console.log("Testing /api/school-years endpoint...");
        const response = await axios_1.default.get('http://localhost:5006/api/school-years');
        console.log("Response status:", response.status);
        console.log("First school year data:", JSON.stringify(response.data[0], null, 2));
    }
    catch (error) {
        console.error("Error:", error.message);
    }
};
run();
