"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const Attendance_1 = __importDefault(require("./models/Attendance"));
const run = async () => {
    try {
        console.log("Testing direct DB insertion...");
        await database_1.default.authenticate();
        console.log("Connected to database.");
        // Test 1: Check if attendance table exists
        const tables = await database_1.default.getQueryInterface().showAllTables();
        console.log("Tables:", tables);
        // Test 2: Try to insert a record directly
        const testRecord = await Attendance_1.default.create({
            eleve_id: 1,
            date: '2026-02-16',
            statut: 'retard',
            motif: 'Test insertion',
            time: '08:30',
            school_year_id: 1
        });
        console.log("✅ Record created:", testRecord.toJSON());
        // Test 3: Fetch all records
        const all = await Attendance_1.default.findAll();
        console.log(`Total attendance records: ${all.length}`);
    }
    catch (error) {
        console.error("❌ Error:", error.message);
        console.error("Stack:", error.stack);
    }
    finally {
        await database_1.default.close();
    }
};
run();
