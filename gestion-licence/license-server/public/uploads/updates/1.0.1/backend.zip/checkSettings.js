"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
async function checkSettings() {
    try {
        await models_1.sequelize.authenticate();
        const settings = await models_1.SchoolSettings.findOne();
        console.log('Current Settings:', settings ? settings.toJSON() : 'No settings found');
        process.exit(0);
    }
    catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}
checkSettings();
