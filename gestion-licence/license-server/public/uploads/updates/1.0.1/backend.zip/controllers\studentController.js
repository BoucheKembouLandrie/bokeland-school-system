"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transferStudents = exports.getStudentsWithAverage = exports.deleteStudent = exports.updateStudent = exports.createStudent = exports.getStudentById = exports.getAllStudents = void 0;
const Student_1 = __importDefault(require("../models/Student"));
const Class_1 = __importDefault(require("../models/Class"));
const matriculeGenerator_1 = require("../utils/matriculeGenerator");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const getAllStudents = async (req, res) => {
    const logPath = path_1.default.join(__dirname, '../../debug_log.txt');
    try {
        fs_1.default.appendFileSync(logPath, `[API] getAllStudents Called at ${new Date().toISOString()}\n`);
        const { classe_id } = req.query;
        const schoolYearId = req.headers['x-school-year-id'];
        fs_1.default.appendFileSync(logPath, `[API] Params - Class: ${classe_id}, Year: ${schoolYearId}\n`);
        if (!schoolYearId) {
            console.warn('⚠️ [API] Missing School Year ID');
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const whereClause = { school_year_id: schoolYearId };
        if (classe_id) {
            whereClause.classe_id = classe_id;
        }
        console.log('🔍 [API] Querying Students with:', JSON.stringify(whereClause));
        const students = await Student_1.default.findAll({
            where: whereClause,
            include: [{ model: Class_1.default, as: 'class' }]
        });
        console.log(`✅ [API] Found ${students.length} students`);
        res.json(students);
    }
    catch (error) {
        const logPath = path_1.default.join(__dirname, '../../error_log.txt');
        const errorMessage = `[${new Date().toISOString()}] Error in getAllStudents: ${error.message}\nStack: ${error.stack}\n\n`;
        fs_1.default.appendFileSync(logPath, errorMessage);
        console.error('❌ [API] Error in getAllStudents:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};
exports.getAllStudents = getAllStudents;
const getStudentById = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        const whereClause = { id: req.params.id };
        if (schoolYearId) {
            whereClause.school_year_id = schoolYearId;
        }
        const student = await Student_1.default.findOne({
            where: whereClause,
            include: [{ model: Class_1.default, as: 'class' }]
        });
        if (!student)
            return res.status(404).json({ message: 'Student not found in this school year' });
        res.json(student);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getStudentById = getStudentById;
const createStudent = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const matricule = await (0, matriculeGenerator_1.generateMatricule)();
        const student = await Student_1.default.create({
            ...req.body,
            matricule,
            school_year_id: schoolYearId
        });
        res.status(201).json(student);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createStudent = createStudent;
const updateStudent = async (req, res) => {
    try {
        const student = await Student_1.default.findByPk(req.params.id);
        if (!student)
            return res.status(404).json({ message: 'Student not found' });
        await student.update(req.body);
        res.json(student);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateStudent = updateStudent;
const deleteStudent = async (req, res) => {
    try {
        const student = await Student_1.default.findByPk(req.params.id);
        if (!student)
            return res.status(404).json({ message: 'Student not found' });
        await student.destroy();
        res.json({ message: 'Student deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteStudent = deleteStudent;
// --- Transfer Features ---
const Grade_1 = __importDefault(require("../models/Grade"));
const Subject_1 = __importDefault(require("../models/Subject"));
const getStudentsWithAverage = async (req, res) => {
    try {
        const { classe_id } = req.query;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId || !classe_id) {
            return res.status(400).json({ message: 'School Year ID and Class ID are required' });
        }
        // 1. Get Students
        const students = await Student_1.default.findAll({
            where: {
                classe_id: classe_id,
                school_year_id: schoolYearId
            },
            raw: true
        });
        // 2. Get Grades + Subjects for this class to calculate averages
        // We fetch ALL grades for this class to minimize queries
        // Note: We need to filter grades by students in this class.
        // Direct approach: Fetch grades where student.classe_id = ... (Complex join)
        // Simpler: Fetch grades for the student IDs we just found.
        const studentIds = students.map((s) => s.id);
        if (studentIds.length === 0) {
            return res.json([]);
        }
        const grades = await Grade_1.default.findAll({
            where: {
                eleve_id: studentIds,
                school_year_id: schoolYearId
            },
            include: [{ model: Subject_1.default, as: 'subject' }],
            raw: true,
            nest: true
        });
        // 3. Calculate Average per Student
        const results = students.map((student) => {
            const studentGrades = grades.filter((g) => g.eleve_id === student.id);
            let totalPoints = 0;
            let totalCoeffs = 0;
            studentGrades.forEach((g) => {
                // Ensure note and coeff exist
                if (g.note !== undefined && g.subject && g.subject.coefficient) {
                    totalPoints += g.note * g.subject.coefficient;
                    totalCoeffs += g.subject.coefficient;
                }
            });
            const average = totalCoeffs > 0 ? (totalPoints / totalCoeffs).toFixed(2) : 'N/A';
            return {
                ...student,
                moyenne: average
            };
        });
        res.json(results);
    }
    catch (error) {
        console.error('Error fetching students with average:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getStudentsWithAverage = getStudentsWithAverage;
const transferStudents = async (req, res) => {
    try {
        const { studentIds, destClassId, destYearId } = req.body;
        if (!studentIds || !Array.isArray(studentIds) || !destClassId || !destYearId) {
            return res.status(400).json({ message: 'Invalid payload' });
        }
        // Fetch destination class to compare names
        const destClass = await Class_1.default.findByPk(destClassId);
        if (!destClass) {
            return res.status(404).json({ message: 'Destination class not found' });
        }
        let transferCount = 0;
        for (const studentId of studentIds) {
            const sourceStudent = await Student_1.default.findByPk(studentId, {
                include: [{ model: Class_1.default, as: 'class' }]
            });
            if (sourceStudent) {
                // Determine Category
                let newCategory = 'Non redoublant(e)';
                const studentData = sourceStudent;
                if (studentData.class) {
                    const sourceClass = studentData.class;
                    // If class names match, they are repeating the year
                    if (sourceClass.libelle === destClass.libelle) {
                        newCategory = 'Redoublant(e)';
                    }
                }
                // Generate a NEW matricule for the new year
                const newMatricule = await (0, matriculeGenerator_1.generateMatricule)();
                await Student_1.default.create({
                    nom: sourceStudent.nom,
                    prenom: sourceStudent.prenom,
                    date_naissance: sourceStudent.date_naissance,
                    sexe: sourceStudent.sexe,
                    adresse: sourceStudent.adresse,
                    parent_tel: sourceStudent.parent_tel,
                    classe_id: destClassId,
                    school_year_id: destYearId,
                    matricule: newMatricule,
                    category: newCategory
                });
                transferCount++;
            }
        }
        res.json({ message: 'Transfer successful', count: transferCount });
    }
    catch (error) {
        console.error('Transfer error:', error);
        res.status(500).json({ message: 'Server error during transfer', error });
    }
};
exports.transferStudents = transferStudents;
