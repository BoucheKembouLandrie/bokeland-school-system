"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
class Class extends sequelize_1.Model {
}
Class.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    libelle: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    niveau: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    annee: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    pension: {
        type: sequelize_1.DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0,
    },
    school_year_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'school_years',
            key: 'id',
        },
    },
    // Legacy/Missing columns found during debugging
    title: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    nom: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
}, {
    sequelize: database_1.default,
    tableName: 'classes',
});
exports.default = Class;
