"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authController_1 = require("../controllers/authController");
const authMiddleware_1 = require("../middlewares/authMiddleware");
const router = (0, express_1.Router)();
router.post('/login', authController_1.login);
router.post('/register', authController_1.register); // Optional: for initial setup
router.get('/me', authMiddleware_1.authenticateToken, authController_1.getMe);
router.post('/forgot-password', authController_1.forgotPassword);
exports.default = router;
