"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
class SchoolYear extends sequelize_1.Model {
}
SchoolYear.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    name: {
        type: sequelize_1.DataTypes.STRING(20),
        allowNull: false,
        unique: true,
        validate: {
            is: /^\d{4}-\d{4}$/, // Format: YYYY-YYYY
        },
    },
    startYear: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        field: 'start_year', // Explicit mapping
        validate: {
            min: 2000,
            max: 2100,
        },
    },
    endYear: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        field: 'end_year', // Explicit mapping
        validate: {
            min: 2000,
            max: 2100,
        },
    },
    isActive: {
        type: sequelize_1.DataTypes.BOOLEAN,
        defaultValue: false,
        field: 'is_active', // Explicit mapping
    },
}, {
    sequelize: database_1.default,
    tableName: 'school_years',
    timestamps: true,
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
});
exports.default = SchoolYear;
