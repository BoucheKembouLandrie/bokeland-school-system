"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
const addUserRoleFields = async () => {
    try {
        const queryInterface = database_1.default.getQueryInterface();
        console.log('Checking existing columns...');
        const tableDescription = await queryInterface.describeTable('users');
        console.log('Current columns:', Object.keys(tableDescription));
        // Add is_default column
        if (!tableDescription.is_default) {
            console.log('Adding is_default column...');
            await queryInterface.addColumn('users', 'is_default', {
                type: sequelize_1.DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false,
            });
            console.log('✓ Column "is_default" added');
        }
        else {
            console.log('✓ Column "is_default" already exists');
        }
        // Add teacher_id column
        if (!tableDescription.teacher_id) {
            console.log('Adding teacher_id column...');
            await queryInterface.addColumn('users', 'teacher_id', {
                type: sequelize_1.DataTypes.INTEGER,
                allowNull: true,
            });
            console.log('✓ Column "teacher_id" added');
        }
        else {
            console.log('✓ Column "teacher_id" already exists');
        }
        // Add permissions column
        if (!tableDescription.permissions) {
            console.log('Adding permissions column...');
            await queryInterface.addColumn('users', 'permissions', {
                type: sequelize_1.DataTypes.JSON,
                allowNull: true,
            });
            console.log('✓ Column "permissions" added');
        }
        else {
            console.log('✓ Column "permissions" already exists');
        }
        // Set is_default = true for the admin user
        console.log('Updating admin user...');
        await database_1.default.query("UPDATE users SET is_default = true WHERE username = 'admin' AND role = 'admin'");
        console.log('✓ Admin user marked as default');
        console.log('\n✅ Migration completed successfully!');
    }
    catch (error) {
        console.error('❌ Error during migration:', error);
    }
    finally {
        await database_1.default.close();
    }
};
addUserRoleFields();
