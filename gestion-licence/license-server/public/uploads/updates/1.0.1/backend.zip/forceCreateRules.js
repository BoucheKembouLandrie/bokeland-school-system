"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const ExamRule_1 = __importDefault(require("./models/ExamRule"));
const forceCreateTable = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        console.log('Forcing creation of ExamRule table...');
        await ExamRule_1.default.sync({ force: true });
        console.log('Table exam_rules created successfully.');
    }
    catch (error) {
        console.error('Error creating table:', error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
forceCreateTable();
