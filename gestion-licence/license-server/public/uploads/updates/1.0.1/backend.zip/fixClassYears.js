"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const Class_1 = __importDefault(require("./models/Class"));
const SchoolYear_1 = __importDefault(require("./models/SchoolYear"));
const fixClasses = async () => {
    try {
        console.log('Starting Class year repair...');
        // Fetch all classes
        const classes = await Class_1.default.findAll();
        console.log(`Found ${classes.length} classes to check.`);
        let updateCount = 0;
        for (const startClass of classes) {
            const schoolYear = await SchoolYear_1.default.findByPk(startClass.school_year_id);
            if (schoolYear && startClass.annee !== schoolYear.name) {
                console.log(`Fixing Class ${startClass.id} (${startClass.libelle}): ${startClass.annee} -> ${schoolYear.name}`);
                await startClass.update({ annee: schoolYear.name });
                updateCount++;
            }
        }
        console.log(`Repair complete. Updated ${updateCount} classes.`);
    }
    catch (error) {
        console.error('Error repairing classes:', error);
    }
    finally {
        await database_1.default.close();
    }
};
fixClasses();
