"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
class Expense extends sequelize_1.Model {
}
Expense.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    titre: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    montant: {
        type: sequelize_1.DataTypes.DECIMAL(10, 2),
        allowNull: false,
    },
    date_depense: {
        type: sequelize_1.DataTypes.DATEONLY,
        allowNull: false,
    },
    description: {
        type: sequelize_1.DataTypes.TEXT,
        allowNull: true,
    },
    category: {
        type: sequelize_1.DataTypes.ENUM('generale', 'salaire'),
        allowNull: false,
        defaultValue: 'generale',
    },
    status: {
        type: sequelize_1.DataTypes.ENUM('payé', 'en_attente'),
        allowNull: false,
        defaultValue: 'payé',
    },
    teacher_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'teachers',
            key: 'id',
        },
    },
    staff_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'staff',
            key: 'id',
        },
    },
    school_year_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'school_years',
            key: 'id',
        },
    },
}, {
    sequelize: database_1.default,
    tableName: 'expenses',
});
exports.default = Expense;
