"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const suggestionController_1 = require("../controllers/suggestionController");
const router = express_1.default.Router();
router.post('/', suggestionController_1.sendSuggestion);
exports.default = router;
