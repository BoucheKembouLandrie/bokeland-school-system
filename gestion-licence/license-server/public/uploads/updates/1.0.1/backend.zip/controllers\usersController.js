"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUser = exports.updateUser = exports.createUser = exports.getAllUsers = void 0;
const User_1 = __importDefault(require("../models/User"));
const Teacher_1 = __importDefault(require("../models/Teacher"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const emailService_1 = require("../services/emailService");
// Get all users (admin only)
const getAllUsers = async (req, res) => {
    try {
        const users = await User_1.default.findAll({
            attributes: ['id', 'username', 'email', 'role', 'is_default', 'teacher_id', 'permissions'],
            include: [{
                    model: Teacher_1.default,
                    as: 'teacher',
                    attributes: ['id', 'nom', 'prenom'],
                    required: false
                }]
        });
        res.json(users);
    }
    catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllUsers = getAllUsers;
// Create new user (admin only)
const createUser = async (req, res) => {
    try {
        const { username, password, email, role, teacher_id, permissions } = req.body;
        // Validate required fields
        if (!username || !password || !role) {
            return res.status(400).json({ message: 'Username, password, and role are required' });
        }
        // Validate role-specific fields
        if (role === 'teacher' && !teacher_id) {
            return res.status(400).json({ message: 'Teacher ID is required for teacher accounts' });
        }
        if (role === 'secretary' && !permissions) {
            return res.status(400).json({ message: 'Permissions are required for secretary accounts' });
        }
        // Check if username already exists
        const existingUser = await User_1.default.findOne({ where: { username } });
        if (existingUser) {
            return res.status(400).json({ message: 'Username already exists' });
        }
        // Hash password
        const hashedPassword = await bcrypt_1.default.hash(password, 10);
        // Create user
        const user = await User_1.default.create({
            username,
            password: hashedPassword,
            email: email || null,
            role,
            is_default: false,
            teacher_id: role === 'teacher' ? teacher_id : null,
            permissions: role === 'secretary' ? permissions : null,
        });
        res.status(201).json({
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            is_default: user.is_default,
            teacher_id: user.teacher_id,
            permissions: user.permissions,
        });
    }
    catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createUser = createUser;
// Update user (admin only, cannot update default admin)
const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const { username, password, email, role, teacher_id, permissions } = req.body;
        const user = await User_1.default.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        // Prevent updating default admin
        // Prevent changing critical fields for default admin
        if (user.is_default) {
            if (username && username !== user.username) {
                return res.status(403).json({ message: 'Cannot change username of default admin' });
            }
            if (role && role !== user.role) {
                return res.status(403).json({ message: 'Cannot change role of default admin' });
            }
            // Allow password/email/teacher_id (though default admin isn't usually a teacher)
        }
        // Prepare update data
        const updateData = {};
        if (username)
            updateData.username = username;
        if (email !== undefined)
            updateData.email = email || null;
        if (role)
            updateData.role = role;
        if (password) {
            updateData.password = await bcrypt_1.default.hash(password, 10);
        }
        // Update role-specific fields
        if (role === 'teacher') {
            updateData.teacher_id = teacher_id;
            updateData.permissions = null;
        }
        else if (role === 'secretary') {
            updateData.permissions = permissions;
            updateData.teacher_id = null;
        }
        else {
            updateData.teacher_id = null;
            updateData.permissions = null;
        }
        const oldEmail = user.email;
        await user.update(updateData);
        // Notify if email changed (only if new email is provided and different)
        if (updateData.email && oldEmail !== updateData.email) {
            if (oldEmail) {
                (0, emailService_1.sendEmailChangeNotification)(oldEmail, user.username, updateData.email).catch(console.error);
            }
            (0, emailService_1.sendEmailChangeNotification)(updateData.email, user.username, updateData.email).catch(console.error);
        }
        res.json({
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            is_default: user.is_default,
            teacher_id: user.teacher_id,
            permissions: user.permissions,
        });
    }
    catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateUser = updateUser;
// Delete user (admin only, cannot delete default admin)
const deleteUser = async (req, res) => {
    try {
        const { id } = req.params;
        const user = await User_1.default.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        // Prevent deleting default admin
        if (user.is_default) {
            return res.status(403).json({ message: 'Cannot delete the default admin account' });
        }
        await user.destroy();
        res.json({ message: 'User deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteUser = deleteUser;
