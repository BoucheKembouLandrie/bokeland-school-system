"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubjectCategory = exports.ExamRule = exports.Schedule = exports.SchoolYear = exports.Staff = exports.Expense = exports.Evaluation = exports.SchoolSettings = exports.Attendance = exports.Payment = exports.Grade = exports.Subject = exports.Student = exports.Teacher = exports.Class = exports.User = exports.sequelize = void 0;
const database_1 = __importDefault(require("../config/database"));
exports.sequelize = database_1.default;
const User_1 = __importDefault(require("./User"));
exports.User = User_1.default;
const Class_1 = __importDefault(require("./Class"));
exports.Class = Class_1.default;
const Teacher_1 = __importDefault(require("./Teacher"));
exports.Teacher = Teacher_1.default;
const Student_1 = __importDefault(require("./Student"));
exports.Student = Student_1.default;
const Subject_1 = __importDefault(require("./Subject"));
exports.Subject = Subject_1.default;
const Grade_1 = __importDefault(require("./Grade"));
exports.Grade = Grade_1.default;
const Payment_1 = __importDefault(require("./Payment"));
exports.Payment = Payment_1.default;
const Attendance_1 = __importDefault(require("./Attendance"));
exports.Attendance = Attendance_1.default;
const SchoolSettings_1 = __importDefault(require("./SchoolSettings"));
exports.SchoolSettings = SchoolSettings_1.default;
const Evaluation_1 = __importDefault(require("./Evaluation"));
exports.Evaluation = Evaluation_1.default;
const Expense_1 = __importDefault(require("./Expense"));
exports.Expense = Expense_1.default;
const Staff_1 = __importDefault(require("./Staff"));
exports.Staff = Staff_1.default;
const SchoolYear_1 = __importDefault(require("./SchoolYear"));
exports.SchoolYear = SchoolYear_1.default;
const Schedule_1 = __importDefault(require("./Schedule"));
exports.Schedule = Schedule_1.default;
const ExamRule_1 = __importDefault(require("./ExamRule"));
exports.ExamRule = ExamRule_1.default;
const SubjectCategory_1 = __importDefault(require("./SubjectCategory"));
exports.SubjectCategory = SubjectCategory_1.default;
// Associations
// SchoolYear <-> Data Models (students, teachers, classes, etc.)
SchoolYear_1.default.hasMany(Student_1.default, { foreignKey: 'school_year_id', as: 'students' });
Student_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Teacher_1.default, { foreignKey: 'school_year_id', as: 'teachers' });
Teacher_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Class_1.default, { foreignKey: 'school_year_id', as: 'classes' });
Class_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Subject_1.default, { foreignKey: 'school_year_id', as: 'subjects' });
Subject_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Grade_1.default, { foreignKey: 'school_year_id', as: 'grades' });
Grade_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Payment_1.default, { foreignKey: 'school_year_id', as: 'payments' });
Payment_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Attendance_1.default, { foreignKey: 'school_year_id', as: 'attendance' });
Attendance_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Evaluation_1.default, { foreignKey: 'school_year_id', as: 'evaluations' });
Evaluation_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Staff_1.default, { foreignKey: 'school_year_id', as: 'staff' });
Staff_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Expense_1.default, { foreignKey: 'school_year_id', as: 'expenses' });
Expense_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
// Class <-> Student
Class_1.default.hasMany(Student_1.default, { foreignKey: 'classe_id', as: 'students' });
Student_1.default.belongsTo(Class_1.default, { foreignKey: 'classe_id', as: 'class' });
// Teacher <-> Subject
Teacher_1.default.hasMany(Subject_1.default, { foreignKey: 'teacher_id', as: 'subjects' });
Subject_1.default.belongsTo(Teacher_1.default, { foreignKey: 'teacher_id', as: 'teacher' });
// Class <-> Subject
Class_1.default.hasMany(Subject_1.default, { foreignKey: 'classe_id', as: 'subjects' });
Subject_1.default.belongsTo(Class_1.default, { foreignKey: 'classe_id', as: 'class' });
// Student <-> Grade
Student_1.default.hasMany(Grade_1.default, { foreignKey: 'eleve_id', as: 'grades' });
Grade_1.default.belongsTo(Student_1.default, { foreignKey: 'eleve_id', as: 'student' });
// Subject <-> Grade
Subject_1.default.hasMany(Grade_1.default, { foreignKey: 'matiere_id', as: 'grades' });
Grade_1.default.belongsTo(Subject_1.default, { foreignKey: 'matiere_id', as: 'subject' });
// Student <-> Payment
Student_1.default.hasMany(Payment_1.default, { foreignKey: 'eleve_id', as: 'payments' });
Payment_1.default.belongsTo(Student_1.default, { foreignKey: 'eleve_id', as: 'student' });
// Student <-> Attendance
Student_1.default.hasMany(Attendance_1.default, { foreignKey: 'eleve_id', as: 'attendance' });
Attendance_1.default.belongsTo(Student_1.default, { foreignKey: 'eleve_id', as: 'student' });
// User <-> Teacher (for teacher accounts)
Teacher_1.default.hasOne(User_1.default, { foreignKey: 'teacher_id', as: 'user' });
User_1.default.belongsTo(Teacher_1.default, { foreignKey: 'teacher_id', as: 'teacher' });
// Expense associations
Expense_1.default.belongsTo(Teacher_1.default, { foreignKey: 'teacher_id', as: 'teacher' });
Teacher_1.default.hasMany(Expense_1.default, { foreignKey: 'teacher_id', as: 'expenses' });
Expense_1.default.belongsTo(Staff_1.default, { foreignKey: 'staff_id', as: 'staffMember' });
Staff_1.default.hasMany(Expense_1.default, { foreignKey: 'staff_id', as: 'expenses' });
// Schedule associations
Schedule_1.default.belongsTo(Subject_1.default, { foreignKey: 'subject_id', as: 'subject' });
Subject_1.default.hasMany(Schedule_1.default, { foreignKey: 'subject_id', as: 'schedules' });
Schedule_1.default.belongsTo(SchoolYear_1.default, { foreignKey: 'school_year_id', as: 'schoolYear' });
SchoolYear_1.default.hasMany(Schedule_1.default, { foreignKey: 'school_year_id', as: 'schedules' });
// SubjectCategory <-> Subject
SubjectCategory_1.default.hasMany(Subject_1.default, { foreignKey: 'category_id', as: 'subjects' });
Subject_1.default.belongsTo(SubjectCategory_1.default, { foreignKey: 'category_id', as: 'category' });
