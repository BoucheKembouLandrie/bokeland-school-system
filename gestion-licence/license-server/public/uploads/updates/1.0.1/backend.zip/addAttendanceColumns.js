"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
const addAttendanceColumns = async () => {
    try {
        const queryInterface = database_1.default.getQueryInterface();
        const tableDescription = await queryInterface.describeTable('attendance');
        if (!tableDescription.motif) {
            await queryInterface.addColumn('attendance', 'motif', {
                type: sequelize_1.DataTypes.STRING,
                allowNull: true,
            });
            console.log('Column "motif" added successfully.');
        }
        else {
            console.log('Column "motif" already exists.');
        }
        if (!tableDescription.time) {
            await queryInterface.addColumn('attendance', 'time', {
                type: sequelize_1.DataTypes.STRING,
                allowNull: true,
            });
            console.log('Column "time" added successfully.');
        }
        else {
            console.log('Column "time" already exists.');
        }
    }
    catch (error) {
        console.error('Error adding columns:', error);
    }
    finally {
        await database_1.default.close();
    }
};
addAttendanceColumns();
