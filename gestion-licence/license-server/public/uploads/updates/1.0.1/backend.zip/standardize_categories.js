"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const Student_1 = __importDefault(require("./models/Student"));
const standardizeCategories = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected to database.');
        // Update students having 'Non redoublant' to 'Non redoublant(e)'
        const [updatedCount] = await Student_1.default.update({ category: 'Non redoublant(e)' }, {
            where: {
                category: 'Non redoublant'
            }
        });
        console.log(`✅ Updated ${updatedCount} students from 'Non redoublant' to 'Non redoublant(e)'`);
        // Update 'Redoublant' to 'Redoublant(e)' if any
        const [updatedRedoublantCount] = await Student_1.default.update({ category: 'Redoublant(e)' }, {
            where: {
                category: 'Redoublant'
            }
        });
        console.log(`✅ Updated ${updatedRedoublantCount} students from 'Redoublant' to 'Redoublant(e)'`);
        // Verify
        const students = await Student_1.default.findAll({ limit: 5, order: [['updatedAt', 'DESC']] });
        console.log('Sample updated students:', JSON.stringify(students.map(s => ({ nom: s.nom, category: s.category })), null, 2));
    }
    catch (error) {
        console.error('Error updating categories:', error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
standardizeCategories();
