"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const models_1 = require("./models");
async function createAdminUser() {
    try {
        await models_1.sequelize.authenticate();
        console.log('Database connected.');
        await models_1.sequelize.sync();
        console.log('Models synchronized.');
        const hashedPassword = await bcrypt_1.default.hash('admin123', 10);
        const [user, created] = await models_1.User.findOrCreate({
            where: { username: 'admin' },
            defaults: {
                username: 'admin',
                password: hashedPassword,
                role: 'admin',
            },
        });
        if (created) {
            console.log('✅ Admin user created successfully!');
            console.log('Username: admin');
            console.log('Password: admin123');
        }
        else {
            console.log('ℹ️  Admin user already exists.');
        }
        process.exit(0);
    }
    catch (error) {
        console.error('Error creating admin user:', error);
        process.exit(1);
    }
}
createAdminUser();
