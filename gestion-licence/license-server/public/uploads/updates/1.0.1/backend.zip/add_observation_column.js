"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const run = async () => {
    try {
        await models_1.sequelize.authenticate();
        const queryInterface = models_1.sequelize.getQueryInterface();
        try {
            await queryInterface.addColumn('grades', 'observation', {
                type: 'VARCHAR(255)',
                allowNull: true
            });
            console.log("Column 'observation' added successfully.");
        }
        catch (error) {
            if (error.message.includes('Duplicate column')) {
                console.log("Column 'observation' already exists.");
            }
            else {
                throw error;
            }
        }
    }
    catch (error) {
        console.error("Error updating schema:", error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
