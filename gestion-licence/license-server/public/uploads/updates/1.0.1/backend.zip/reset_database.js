"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const resetDatabase = async () => {
    try {
        console.log('🔄 Starting local database reset...');
        await models_1.sequelize.sync({ force: true });
        console.log('✅ Local database reset complete!');
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Database reset failed:', error);
        process.exit(1);
    }
};
resetDatabase();
