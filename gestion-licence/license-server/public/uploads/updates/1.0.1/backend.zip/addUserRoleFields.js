"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
const addUserRoleFields = async () => {
    try {
        const queryInterface = database_1.default.getQueryInterface();
        const tableDescription = await queryInterface.describeTable('users');
        // Add is_default column
        if (!tableDescription.is_default) {
            await queryInterface.addColumn('users', 'is_default', {
                type: sequelize_1.DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: false,
            });
            console.log('Column "is_default" added successfully.');
        }
        else {
            console.log('Column "is_default" already exists.');
        }
        // Add teacher_id column
        if (!tableDescription.teacher_id) {
            await queryInterface.addColumn('users', 'teacher_id', {
                type: sequelize_1.DataTypes.INTEGER,
                allowNull: true,
                references: {
                    model: 'teachers',
                    key: 'id',
                },
                onUpdate: 'CASCADE',
                onDelete: 'SET NULL',
            });
            console.log('Column "teacher_id" added successfully.');
        }
        else {
            console.log('Column "teacher_id" already exists.');
        }
        // Add permissions column
        if (!tableDescription.permissions) {
            await queryInterface.addColumn('users', 'permissions', {
                type: sequelize_1.DataTypes.JSON,
                allowNull: true,
            });
            console.log('Column "permissions" added successfully.');
        }
        else {
            console.log('Column "permissions" already exists.');
        }
        // Set is_default = true for the admin user
        await database_1.default.query("UPDATE users SET is_default = true WHERE username = 'admin' AND role = 'admin'", { type: sequelize_1.QueryTypes.UPDATE });
        console.log('Default admin account marked as is_default = true.');
    }
    catch (error) {
        console.error('Error adding columns:', error);
    }
    finally {
        await database_1.default.close();
    }
};
addUserRoleFields();
