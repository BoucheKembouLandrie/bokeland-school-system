"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
const Student_1 = __importDefault(require("./Student"));
class Payment extends sequelize_1.Model {
}
Payment.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    eleve_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Student_1.default,
            key: 'id',
        },
    },
    montant: {
        type: sequelize_1.DataTypes.FLOAT,
        allowNull: false,
    },
    date_paiement: {
        type: sequelize_1.DataTypes.DATE,
        defaultValue: sequelize_1.DataTypes.NOW,
    },
    motif: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    reste: {
        type: sequelize_1.DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 0,
    },
    school_year_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'school_years',
            key: 'id',
        },
    },
}, {
    sequelize: database_1.default,
    tableName: 'payments',
});
exports.default = Payment;
