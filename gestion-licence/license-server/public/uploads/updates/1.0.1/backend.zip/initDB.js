"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const promise_1 = __importDefault(require("mysql2/promise"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Construct the path to .env file relative to this script
dotenv_1.default.config({ path: path_1.default.join(__dirname, '../../.env') });
const initDB = async () => {
    try {
        const connection = await promise_1.default.createConnection({
            host: process.env.DB_HOST || 'localhost',
            port: Number(process.env.DB_PORT) || 3308,
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASS || '',
        });
        const dbName = process.env.DB_NAME || 'leuana_school_db';
        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\`;`);
        console.log(`Database '${dbName}' ensured to exist.`);
        await connection.end();
    }
    catch (err) {
        console.error('Failed to initialize database:', err);
    }
};
initDB();
