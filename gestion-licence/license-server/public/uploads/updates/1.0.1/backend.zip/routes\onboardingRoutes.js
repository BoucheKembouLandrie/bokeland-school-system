"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const onboardingController_1 = require("../controllers/onboardingController");
const debugOnboardingController_1 = require("../controllers/debugOnboardingController");
console.log('Loading onboardingRoutes...');
const router = express_1.default.Router();
// POST /api/onboarding/complete
router.post('/complete', onboardingController_1.completeOnboarding);
// POST /api/onboarding/debug (temporary debug endpoint)
router.post('/debug', debugOnboardingController_1.debugOnboarding);
// GET /api/onboarding/status
router.get('/status', onboardingController_1.getOnboardingStatus);
exports.default = router;
