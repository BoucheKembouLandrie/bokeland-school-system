"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const User_1 = __importDefault(require("./models/User"));
const Class_1 = __importDefault(require("./models/Class"));
const Student_1 = __importDefault(require("./models/Student"));
const SchoolSettings_1 = __importDefault(require("./models/SchoolSettings"));
const run = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log("Connected to DB.");
        const users = await User_1.default.findAll();
        console.log(`Users count: ${users.length}`);
        if (users.length > 0) {
            console.log("First User:", users[0].toJSON());
        }
        else {
            console.log("NO USERS FOUND!");
        }
        const classes = await Class_1.default.findAll();
        console.log(`Classes count: ${classes.length}`);
        const students = await Student_1.default.findAll();
        console.log(`Students count: ${students.length}`);
        const settings = await SchoolSettings_1.default.findOne();
        console.log(`Settings: ${settings ? 'Found' : 'Missing'}`);
        if (settings) {
            console.log(`License Status: ${settings.license_status}`);
        }
    }
    catch (error) {
        console.error("Error checking integrity:", error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
