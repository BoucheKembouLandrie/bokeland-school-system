"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOnboardingStatus = exports.completeOnboarding = void 0;
const node_machine_id_1 = require("node-machine-id");
const axios_1 = __importDefault(require("axios"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const SchoolSettings_1 = __importDefault(require("../models/SchoolSettings"));
const SchoolYear_1 = __importDefault(require("../models/SchoolYear"));
const User_1 = __importDefault(require("../models/User"));
const emailService_1 = require("../services/emailService");
const LICENSE_SERVER_URL = process.env.LICENSE_SERVER_URL || 'https://licence.bokelandgroupservices.com';
const isDevelopment = process.env.NODE_ENV === 'development';
/**
 * Register or Update Client on License Server
 */
async function registerToLicenseServer(settings) {
    try {
        const mId = await (0, node_machine_id_1.machineId)();
        const response = await axios_1.default.post(`${LICENSE_SERVER_URL}/api/license/activate`, {
            machine_id: mId,
            school_name: settings.school_name,
            email: settings.email,
            phone: `${settings.country_code || ''} ${settings.phone}`,
            country: settings.country,
            address: settings.address,
            city: '', // Optional
        }, { timeout: 5000 });
        console.log('✓ School registered/synced with License Server:', response.data.message);
    }
    catch (error) {
        console.warn('Could not register with license server:', error.message);
        // Do not block onboarding on license failure
    }
}
/**
 * Check if license is already registered in License Admin Dashboard
 */
async function checkLicenseRegistration(licenseKey) {
    try {
        const response = await axios_1.default.get(`${LICENSE_SERVER_URL}/api/license/check/${licenseKey}`, {
            timeout: 5000,
        });
        return response.data.exists || false;
    }
    catch (error) {
        console.warn('Could not check license registration:', error);
        // In case of error, assume false to allow offline onboarding
        return false;
    }
}
/**
 * Sync school information to License Admin Dashboard
 */
async function syncToLicenseServer(settings, licenseKey) {
    try {
        await axios_1.default.post(`${LICENSE_SERVER_URL}/api/license/update-client-info`, {
            license_key: licenseKey,
            school_name: settings.school_name,
            email: settings.email,
            phone: settings.phone,
            country_code: settings.country_code,
            country: settings.country,
            language: settings.language,
        }, {
            timeout: 5000,
        });
        console.log('✓ School information synced to License Admin Dashboard');
    }
    catch (error) {
        console.warn('Could not sync to license server:', error);
        // Don't fail onboarding if sync fails - data is saved locally
    }
}
/**
 * Complete onboarding process
 * POST /api/onboarding/complete
 */
const completeOnboarding = async (req, res) => {
    try {
        const { school_name, email, phone, country_code, country, address, language, school_year, // New field
         } = req.body;
        // Validate required fields
        if (!school_name || !email || !phone || !country_code || !country || !language) {
            return res.status(400).json({
                message: 'Missing required fields',
            });
        }
        // Validate language
        if (language !== 'fr' && language !== 'en') {
            return res.status(400).json({
                message: 'Invalid language. Must be "fr" or "en"',
            });
        }
        // PROTECTION: Block onboarding in development mode
        if (isDevelopment) {
            console.warn('⚠️  ONBOARDING SIMULATION: Allowing onboarding in development mode as requested.');
            // Protection bypassed for simulation
        }
        // Get current settings to check license key
        let existingSettings;
        try {
            existingSettings = await SchoolSettings_1.default.findOne();
        }
        catch (dbError) {
            throw dbError;
        }
        // PROTECTION: Check if license is already registered
        if (existingSettings?.license_status && existingSettings.license_status !== 'NOT_REGISTERED') {
            const licenseKey = process.env.LICENSE_KEY || '';
            if (licenseKey) {
                const isRegistered = await checkLicenseRegistration(licenseKey);
                if (isRegistered) {
                    console.warn('⚠️  ONBOARDING BLOCKED: License already registered in License Admin Dashboard');
                    return res.status(409).json({
                        message: 'This license is already registered. Contact support if you need to update your information.',
                        alreadyRegistered: true,
                    });
                }
            }
        }
        // Set date format based on language
        const date_format = language === 'en' ? 'MM-DD-YYYY' : 'DD-MM-YYYY';
        // Get or create settings
        let settings = await SchoolSettings_1.default.findOne();
        if (!settings) {
            settings = await SchoolSettings_1.default.create({
                school_name,
                email,
                phone,
                country_code,
                country,
                address,
                language,
                date_format,
                is_onboarding_complete: true,
                logo_url: '/default-logo.png'
            });
        }
        else {
            await settings.update({
                school_name,
                email,
                phone,
                country_code,
                country,
                address,
                language,
                date_format,
                is_onboarding_complete: true,
                logo_url: '/default-logo.png'
            });
        }
        // Initialize School Year
        if (school_year) {
            const match = school_year.match(/^(\d{4})-(\d{4})$/);
            if (match) {
                const startYear = parseInt(match[1]);
                const endYear = parseInt(match[2]);
                await SchoolYear_1.default.update({ isActive: false }, { where: { isActive: true } });
                const [newYear, created] = await SchoolYear_1.default.findOrCreate({
                    where: { name: school_year },
                    defaults: {
                        startYear: startYear,
                        endYear: endYear,
                        isActive: true
                    }
                });
                if (!created) {
                    await newYear.update({ isActive: true });
                }
            }
        }
        // CREATE DEFAULT ADMIN USER if not exists
        let user = await User_1.default.findOne({ where: { username: 'admin' } });
        if (!user) {
            const hashedPassword = await bcrypt_1.default.hash('Admin@123', 10);
            user = await User_1.default.create({
                username: 'admin',
                password: hashedPassword,
                role: 'admin',
                email: email,
                is_default: true
            });
            console.log('✅ Default admin user created');
        }
        // Generate JWT Token
        const token = jsonwebtoken_1.default.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'your_jwt_secret', { expiresIn: '1d' });
        // Sync to license server (with duplicate check)
        const licenseKey = process.env.LICENSE_KEY || '';
        if (licenseKey) {
            await syncToLicenseServer(settings, licenseKey);
        }
        // Always try to register/update machine info
        await registerToLicenseServer(settings);
        // Send Welcome Email
        if (email) {
            await (0, emailService_1.sendWelcomeEmail)(email, school_name, user.username);
        }
        res.json({
            message: 'Onboarding completed successfully',
            settings,
            token,
            user: {
                id: user.id,
                username: user.username,
                role: user.role,
                is_default: user.is_default,
                permissions: user.permissions
            }
        });
    }
    catch (error) {
        console.error('Onboarding error:', error);
        res.status(500).json({
            message: 'Failed to complete onboarding',
            error: error.message || 'Unknown error',
        });
    }
};
exports.completeOnboarding = completeOnboarding;
/**
 * Check onboarding status
 * GET /api/onboarding/status
 */
const getOnboardingStatus = async (req, res) => {
    try {
        const settings = await SchoolSettings_1.default.findOne();
        res.json({
            is_onboarding_complete: settings?.is_onboarding_complete || false,
            has_settings: !!settings,
            // Expose dev mode status so frontend can show appropriate message/handling
            is_development: isDevelopment
        });
    }
    catch (error) {
        console.error('Error checking onboarding status:', error);
        res.status(500).json({
            message: 'Failed to check onboarding status',
            error: error instanceof Error ? error.message : 'Unknown error',
        });
    }
};
exports.getOnboardingStatus = getOnboardingStatus;
