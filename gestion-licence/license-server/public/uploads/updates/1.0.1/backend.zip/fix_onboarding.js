"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const SchoolSettings_1 = __importDefault(require("./models/SchoolSettings"));
const run = async () => {
    try {
        console.log("Authenticating...");
        await models_1.sequelize.authenticate();
        console.log("Connected.");
        const settings = await SchoolSettings_1.default.findOne();
        if (settings) {
            console.log("Current status:", settings.toJSON());
            console.log("Updating is_onboarding_complete to TRUE...");
            // @ts-ignore
            await settings.update({ is_onboarding_complete: true });
            console.log("Updated.");
        }
        else {
            console.log("No settings found. Creating default...");
            await SchoolSettings_1.default.create({
                school_name: "Bokeland School",
                // @ts-ignore
                is_onboarding_complete: true
            });
            console.log("Created default settings.");
        }
    }
    catch (error) {
        console.error("Error:", error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
