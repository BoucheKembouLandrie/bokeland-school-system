"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const sequelize_1 = require("sequelize");
const createEvaluationsTable = async () => {
    try {
        const queryInterface = database_1.default.getQueryInterface();
        console.log('Checking if evaluations table exists...');
        const tables = await queryInterface.showAllTables();
        console.log('Existing tables:', tables);
        if (!tables.includes('evaluations')) {
            console.log('Creating evaluations table...');
            await queryInterface.createTable('evaluations', {
                id: {
                    type: sequelize_1.DataTypes.INTEGER,
                    autoIncrement: true,
                    primaryKey: true,
                },
                nom: {
                    type: sequelize_1.DataTypes.STRING,
                    allowNull: false,
                },
                date_debut: {
                    type: sequelize_1.DataTypes.DATEONLY,
                    allowNull: true,
                },
                date_fin: {
                    type: sequelize_1.DataTypes.DATEONLY,
                    allowNull: true,
                },
                ordre: {
                    type: sequelize_1.DataTypes.INTEGER,
                    allowNull: false,
                    defaultValue: 0,
                },
                createdAt: {
                    type: sequelize_1.DataTypes.DATE,
                    allowNull: false,
                },
                updatedAt: {
                    type: sequelize_1.DataTypes.DATE,
                    allowNull: false,
                },
            });
            console.log('✓ Table "evaluations" created successfully!');
        }
        else {
            console.log('✓ Table "evaluations" already exists');
        }
        console.log('\n✅ Migration completed successfully!');
    }
    catch (error) {
        console.error('❌ Error during migration:', error);
    }
    finally {
        await database_1.default.close();
    }
};
createEvaluationsTable();
