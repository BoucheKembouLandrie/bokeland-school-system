"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const models_1 = require("./models");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
async function check() {
    try {
        await database_1.default.authenticate();
        console.log('--- DB Config ---');
        console.log('DB Name:', database_1.default.config.database);
        console.log('DB Host:', database_1.default.config.host);
        console.log('DB Port:', database_1.default.config.port);
        console.log('\n--- Content Check ---');
        const count = await models_1.Expense.count({ where: { school_year_id: 5 } });
        console.log(`Expenses for Year 5: ${count}`);
        // Also check if year 5 exists
        const year = await database_1.default.query('SELECT * FROM school_years WHERE id = 5');
        console.log('Year 5 Record:', JSON.stringify(year[0]));
        process.exit(0);
    }
    catch (e) {
        console.error(e);
        process.exit(1);
    }
}
check();
