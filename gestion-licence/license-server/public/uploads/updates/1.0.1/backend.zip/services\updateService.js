"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.installUpdate = exports.getUpdateStatus = exports.initUpdateService = void 0;
const socket_io_client_1 = require("socket.io-client");
const licenseService_1 = require("./licenseService");
const models_1 = require("../models");
const SchoolSettings_1 = __importDefault(require("../models/SchoolSettings"));
const axios_1 = __importDefault(require("axios"));
let updateState = {
    available: false,
    inProgress: false,
    version: null,
    changelog: null
};
const initUpdateService = async () => {
    try {
        const license = await (0, licenseService_1.checkLicense)(true);
        const settings = await SchoolSettings_1.default.findOne();
        if (license && settings && settings.email) {
            const socket = (0, socket_io_client_1.io)('https://licence.bokelandgroupservices.com');
            socket.on('connect', () => {
                console.log('[Updater] Connected to License Server');
                socket.emit('register_client', { email: settings.email });
            });
            socket.on('update_available', (data) => {
                console.log('[Updater] Update received:', data);
                updateState.available = true;
                updateState.version = data.version;
                updateState.changelog = data.changelog;
            });
            socket.on('disconnect', () => {
                console.log('[Updater] Disconnected from License Server');
            });
            // Check for missed updates on startup
            try {
                console.log(`[Updater] Checking for missed updates for ${settings.email}...`);
                const res = await axios_1.default.get(`https://licence.bokelandgroupservices.com/api/admin/updates/latest/${settings.email}`);
                if (res.data && res.data.update_available) {
                    console.log('[Updater] Missed update detected:', res.data.update);
                    updateState.available = true;
                    updateState.version = res.data.update.version;
                    updateState.changelog = res.data.update.changelog;
                }
            }
            catch (err) {
                console.error('[Updater] Failed to fetch missed updates:', err);
            }
        }
    }
    catch (error) {
        console.error('[Updater] Failed to init update service:', error);
    }
};
exports.initUpdateService = initUpdateService;
const getUpdateStatus = () => {
    return updateState;
};
exports.getUpdateStatus = getUpdateStatus;
const safeMigration = async () => {
    console.log('[Updater] Starting safe database migration...');
    // Simulated Example: Add new column if it doesn't exist
    // In production, this would read from manifest.json
    try {
        const tableDescription = await models_1.sequelize.getQueryInterface().describeTable('school_settings');
        const columns = Object.keys(tableDescription);
        // Emulating a protected schema update
        if (!columns.includes('new_feature_flag')) {
            console.log('[Updater] Adding new column new_feature_flag to school_settings...');
            await models_1.sequelize.query("ALTER TABLE school_settings ADD COLUMN new_feature_flag BOOLEAN DEFAULT false;");
        }
        console.log('[Updater] Database structure integrity verified. No columns were removed.');
        return true;
    }
    catch (e) {
        console.error('[Updater] Migration failed, database protected:', e);
        throw e;
    }
};
const installUpdate = async () => {
    if (updateState.inProgress)
        throw new Error('Installation already in progress');
    updateState.inProgress = true;
    try {
        console.log('[Updater] Downloading files (simulated)...');
        await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate download
        console.log('[Updater] Replacing application files (simulated)...');
        // Unzipping logic would go here
        await safeMigration();
        console.log('[Updater] Installation complete. Ready for restart.');
        updateState.available = false;
        updateState.inProgress = false;
        return true;
    }
    catch (error) {
        updateState.inProgress = false;
        throw error;
    }
};
exports.installUpdate = installUpdate;
