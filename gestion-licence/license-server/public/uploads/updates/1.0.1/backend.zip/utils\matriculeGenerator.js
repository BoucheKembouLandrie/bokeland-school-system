"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateMatricule = void 0;
const Student_1 = __importDefault(require("../models/Student"));
const sequelize_1 = require("sequelize");
const generateMatricule = async () => {
    const year = new Date().getFullYear();
    const prefix = `LEU-${year}-`;
    const lastStudent = await Student_1.default.findOne({
        where: {
            matricule: {
                [sequelize_1.Op.like]: `${prefix}%`,
            },
        },
        order: [['matricule', 'DESC']],
    });
    let sequence = 1;
    if (lastStudent) {
        const lastMatricule = lastStudent.matricule;
        const lastSequence = parseInt(lastMatricule.split('-')[2], 10);
        sequence = lastSequence + 1;
    }
    return `${prefix}${sequence.toString().padStart(4, '0')}`;
};
exports.generateMatricule = generateMatricule;
