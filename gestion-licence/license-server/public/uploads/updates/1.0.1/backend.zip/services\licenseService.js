"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCachedLicenseStatus = exports.initiatePayment = exports.activateLicense = exports.checkLicense = exports.getMachineFingerprint = void 0;
const node_machine_id_1 = require("node-machine-id");
const axios_1 = __importDefault(require("axios"));
// License Server URL (could be in .env in production)
const LICENSE_SERVER_URL = process.env.LICENSE_SERVER_URL || 'https://licence.bokelandgroupservices.com';
// In-memory cache for license status to avoid hitting the server on every request
let cachedLicenseStatus = null;
let lastCheckTime = 0;
const CHECK_INTERVAL = 1000 * 60 * 5; // 5 minutes (reduced from 1 hour for faster sync)
const getMachineFingerprint = async () => {
    try {
        const id = await (0, node_machine_id_1.machineId)();
        return id;
    }
    catch (error) {
        console.error('Error generating machine ID:', error);
        return 'unknown-machine-id';
    }
};
exports.getMachineFingerprint = getMachineFingerprint;
const SchoolSettings_1 = __importDefault(require("../models/SchoolSettings"));
const checkLicense = async (force = false) => {
    // 1. Fetch Local Settings
    const settings = await SchoolSettings_1.default.findOne();
    const localStatus = settings?.license_status || 'NOT_REGISTERED';
    const localExpiration = settings?.license_expiration_date;
    // 2. Try to connect to Server
    try {
        const fingerPrint = await (0, exports.getMachineFingerprint)();
        console.log('Checking license online for:', fingerPrint);
        const payload = {
            machine_id: fingerPrint
        };
        if (settings) {
            payload.school_name = settings.school_name;
            payload.email = settings.email;
            payload.phone = settings.phone || null;
            payload.address = settings.address || null;
            payload.country = settings.country || null;
        }
        const response = await axios_1.default.post(`${LICENSE_SERVER_URL}/api/license/check`, payload, { timeout: 5000 });
        const serverData = response.data;
        // SERVER AUTHORITY LOGIC:
        // Always trust the server. If server says expired, it's expired.
        // If server says active with new date, update local.
        if (settings) {
            settings.license_status = serverData.status;
            settings.license_expiration_date = serverData.expiration_date;
            settings.license_check_date = new Date(); // Update sync timestamp
            await settings.save();
            console.log('License synced with server:', serverData.status);
        }
        cachedLicenseStatus = serverData;
        lastCheckTime = Date.now();
        return cachedLicenseStatus;
    }
    catch (error) {
        console.warn('License Server unreachable, ensuring offline enforcement:', error.message);
        // OFFLINE LOGIC:
        // Use local settings but ENFORCE expiration strictly
        if (!settings) {
            return { status: 'NOT_REGISTERED', message: 'Pas de licence locale valide trouvé. Connexion internet requise.' };
        }
        if (!settings.license_expiration_date) {
            // New installation without expiration date yet -> Default to TRIAL
            return {
                status: 'TRIAL',
                message: 'Mode Essai - Licence Valide',
                days_remaining: 30
            };
        }
        const now = new Date();
        const expiration = new Date(settings.license_expiration_date);
        // Strict Offline Check
        if (now > expiration) {
            return {
                status: 'EXPIRED',
                expiration_date: expiration,
                days_remaining: 0,
                message: 'Licence expirée (Mode Hors Ligne). Veuillez vous connecter pour renouveler.'
            };
        }
        // Valid Offline Session
        const daysRemaining = Math.ceil((expiration.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        return {
            status: settings.license_status || 'ACTIVE',
            expiration_date: expiration,
            days_remaining: daysRemaining,
            message: 'Mode Hors Ligne - Licence Valide'
        };
    }
};
exports.checkLicense = checkLicense;
const activateLicense = async (schoolName, email) => {
    try {
        const fingerPrint = await (0, exports.getMachineFingerprint)();
        const response = await axios_1.default.post(`${LICENSE_SERVER_URL}/api/license/activate`, {
            machine_id: fingerPrint,
            school_name: schoolName,
            email: email
        });
        // Force refresh cache
        return await (0, exports.checkLicense)(true);
    }
    catch (error) {
        throw new Error(error.response?.data?.error || 'Activation failed');
    }
};
exports.activateLicense = activateLicense;
const initiatePayment = async (amount, phoneNumber) => {
    try {
        const fingerPrint = await (0, exports.getMachineFingerprint)();
        const response = await axios_1.default.post(`${LICENSE_SERVER_URL}/api/license/pay`, {
            machine_id: fingerPrint,
            amount: amount,
            phone_number: phoneNumber
        });
        return response.data;
    }
    catch (error) {
        throw new Error(error.response?.data?.error || 'Payment initiation failed');
    }
};
exports.initiatePayment = initiatePayment;
const getCachedLicenseStatus = () => cachedLicenseStatus;
exports.getCachedLicenseStatus = getCachedLicenseStatus;
