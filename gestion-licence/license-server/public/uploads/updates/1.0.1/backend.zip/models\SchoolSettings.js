"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
class SchoolSettings extends sequelize_1.Model {
}
SchoolSettings.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    school_name: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    website: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    address: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    phone: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    email: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    logo_url: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    license_status: {
        type: sequelize_1.DataTypes.STRING, // 'ACTIVE', 'TRIAL', 'EXPIRED'
        defaultValue: 'TRIAL',
    },
    license_expiration_date: {
        type: sequelize_1.DataTypes.DATE,
        allowNull: true,
    },
    license_check_date: {
        type: sequelize_1.DataTypes.DATE,
        allowNull: true,
    },
    date_format: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
        defaultValue: 'dd/mm/yyyy',
    },
    country_code: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    country: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
    },
    language: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: true,
        defaultValue: 'fr',
    },
    is_onboarding_complete: {
        type: sequelize_1.DataTypes.BOOLEAN,
        defaultValue: false,
    },
}, {
    sequelize: database_1.default,
    tableName: 'school_settings',
});
exports.default = SchoolSettings;
