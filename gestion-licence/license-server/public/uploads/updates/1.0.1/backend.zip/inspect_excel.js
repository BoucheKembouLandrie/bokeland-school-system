"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const exceljs_1 = __importDefault(require("exceljs"));
const path_1 = __importDefault(require("path"));
const inspectExcel = async () => {
    const wb = new exceljs_1.default.Workbook();
    const filePath = path_1.default.join(__dirname, '../test_export.xlsx');
    try {
        await wb.xlsx.readFile(filePath);
        console.log('Successfully read Excel file');
        console.log('Number of sheets:', wb.worksheets.length);
        console.log('Sheet names:', wb.worksheets.map(s => s.name).join(', '));
        wb.worksheets.forEach(sheet => {
            console.log(`\nSheet: ${sheet.name}`);
            console.log(`  Row count: ${sheet.rowCount}`);
            console.log(`  Actual rows: ${sheet.actualRowCount}`);
        });
    }
    catch (err) {
        console.error('Error reading Excel:', err);
    }
};
inspectExcel();
