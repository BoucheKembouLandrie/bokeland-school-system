"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const models_1 = require("./models");
async function createTempAdmin() {
    try {
        await models_1.sequelize.authenticate();
        const hashedPassword = await bcrypt_1.default.hash('temp123', 10);
        await models_1.User.create({
            username: 'temp_debug_admin',
            password: hashedPassword,
            role: 'admin',
        });
        console.log('✅ Temp admin created.');
        process.exit(0);
    }
    catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}
createTempAdmin();
