"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./models"); // Initialize associations
const gradeController_1 = require("./controllers/gradeController");
// Mock objects
const req = {
    query: {
        eleve_id: '1', // Assuming ID 1 exists based on previous debug
        evaluation: 'Evaluation 1',
        classe_id: '1'
    }
};
const res = {
    json: (data) => {
        console.log('Response JSON:', JSON.stringify(data, null, 2));
    },
    status: (code) => {
        console.log('Response Status:', code);
        return res;
    }
};
console.log('Testing getSubjectStats with:', req.query);
(0, gradeController_1.getSubjectStats)(req, res);
