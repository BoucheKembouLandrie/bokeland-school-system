"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("../config/database"));
const SchoolYear_1 = __importDefault(require("../models/SchoolYear"));
const Class_1 = __importDefault(require("../models/Class"));
const Student_1 = __importDefault(require("../models/Student"));
const Subject_1 = __importDefault(require("../models/Subject"));
const Evaluation_1 = __importDefault(require("../models/Evaluation"));
const Grade_1 = __importDefault(require("../models/Grade"));
async function seedGrades() {
    try {
        await database_1.default.authenticate();
        console.log('Connection has been established successfully.');
        const yearName = '2026-2027';
        const className = '5ieme';
        // 1. Get School Year
        const schoolYear = await SchoolYear_1.default.findOne({ where: { name: yearName } });
        if (!schoolYear)
            throw new Error(`School Year ${yearName} not found`);
        // 2. Get Class
        const targetClass = await Class_1.default.findOne({ where: { libelle: className, school_year_id: schoolYear.id } });
        if (!targetClass)
            throw new Error(`Class ${className} not found in ${yearName}`);
        // 3. Get Students
        const students = await Student_1.default.findAll({ where: { classe_id: targetClass.id } });
        console.log(`Found ${students.length} students`);
        // 4. Get Subjects
        const subjects = await Subject_1.default.findAll({ where: { classe_id: targetClass.id } });
        console.log(`Found ${subjects.length} subjects`);
        // 5. Get Evaluations
        const evaluations = await Evaluation_1.default.findAll({ where: { school_year_id: schoolYear.id } });
        console.log(`Found ${evaluations.length} evaluations`);
        // 6. Seed Grades
        let createdCount = 0;
        for (const student of students) {
            for (const subject of subjects) {
                for (const evaluation of evaluations) {
                    // Check if grade exists
                    const existingGrade = await Grade_1.default.findOne({
                        where: {
                            eleve_id: student.id,
                            matiere_id: subject.id,
                            trimestre: evaluation.nom,
                            school_year_id: schoolYear.id
                        }
                    });
                    if (!existingGrade) {
                        // Generate random grade between 5 and 18 (realistic range)
                        const randomGrade = parseFloat((Math.random() * (18 - 5) + 5).toFixed(2));
                        await Grade_1.default.create({
                            eleve_id: student.id,
                            matiere_id: subject.id,
                            note: randomGrade,
                            trimestre: evaluation.nom,
                            annee_scolaire: yearName,
                            school_year_id: schoolYear.id
                        });
                        createdCount++;
                    }
                }
            }
        }
        console.log(`✅ Successfully created ${createdCount} grades!`);
    }
    catch (error) {
        console.error('Error seeding grades:', error);
    }
    finally {
        await database_1.default.close();
    }
}
seedGrades();
