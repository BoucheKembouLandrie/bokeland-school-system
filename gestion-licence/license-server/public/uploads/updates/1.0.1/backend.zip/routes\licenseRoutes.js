"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const licenseService_1 = require("../services/licenseService");
const router = (0, express_1.Router)();
router.post('/activate', async (req, res) => {
    try {
        const { school_name, email } = req.body;
        if (!school_name || !email) {
            res.status(400).json({ error: 'School name and email required' });
            return;
        }
        const result = await (0, licenseService_1.activateLicense)(school_name, email);
        res.json(result);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get('/status', async (req, res) => {
    // Force check if requested (e.g. user clicked "Refresh License")
    const force = req.query.force === 'true';
    const status = await (0, licenseService_1.checkLicense)(force);
    console.log('License Status Response:', JSON.stringify(status, null, 2));
    res.json(status);
});
router.post('/pay', async (req, res) => {
    try {
        const { amount, phone_number } = req.body;
        const result = await (0, licenseService_1.initiatePayment)(amount, phone_number);
        res.json(result);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
