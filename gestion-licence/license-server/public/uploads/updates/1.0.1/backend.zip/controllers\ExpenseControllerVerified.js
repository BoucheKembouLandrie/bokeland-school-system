"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteExpense = exports.updateExpense = exports.createExpense = exports.getAllExpenses = void 0;
const Expense_1 = __importDefault(require("../models/Expense"));
const Teacher_1 = __importDefault(require("../models/Teacher"));
const Staff_1 = __importDefault(require("../models/Staff"));
const getAllExpenses = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        console.log(`[EXPENSE_CTRL] Request for Expenses. ID: ${schoolYearId}`);
        if (!schoolYearId) {
            console.log('[EXPENSE_CTRL] BLOCKED: Missing ID');
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const expenses = await Expense_1.default.findAll({
            where: { school_year_id: schoolYearId },
            order: [['date_depense', 'DESC']],
            include: [
                { model: Teacher_1.default, as: 'teacher' },
                { model: Staff_1.default, as: 'staffMember' }
            ]
        });
        res.json(expenses);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllExpenses = getAllExpenses;
const createExpense = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const expense = await Expense_1.default.create({
            ...req.body,
            school_year_id: schoolYearId
        });
        res.status(201).json(expense);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createExpense = createExpense;
const updateExpense = async (req, res) => {
    try {
        const expense = await Expense_1.default.findByPk(req.params.id);
        if (!expense)
            return res.status(404).json({ message: 'Expense not found' });
        await expense.update(req.body);
        res.json(expense);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateExpense = updateExpense;
const deleteExpense = async (req, res) => {
    try {
        const expense = await Expense_1.default.findByPk(req.params.id);
        if (!expense)
            return res.status(404).json({ message: 'Expense not found' });
        await expense.destroy();
        res.json({ message: 'Expense deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteExpense = deleteExpense;
