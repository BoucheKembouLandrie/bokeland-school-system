"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSchedule = exports.updateSchedule = exports.createSchedule = exports.getSchedulesByClass = exports.getAllSchedules = void 0;
const Schedule_1 = __importDefault(require("../models/Schedule"));
const Subject_1 = __importDefault(require("../models/Subject"));
const Teacher_1 = __importDefault(require("../models/Teacher"));
const getAllSchedules = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const schedules = await Schedule_1.default.findAll({
            where: { school_year_id: schoolYearId },
            include: [
                {
                    model: Subject_1.default,
                    as: 'subject',
                    include: [
                        {
                            model: Teacher_1.default,
                            as: 'teacher',
                            attributes: ['id', 'nom', 'prenom']
                        }
                    ]
                }
            ],
            order: [['day_of_week', 'ASC'], ['start_time', 'ASC']]
        });
        res.json(schedules);
    }
    catch (error) {
        console.error('Error fetching schedules:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllSchedules = getAllSchedules;
const getSchedulesByClass = async (req, res) => {
    try {
        const { classId } = req.params;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const schedules = await Schedule_1.default.findAll({
            where: {
                classe_id: classId,
                school_year_id: schoolYearId
            },
            include: [
                {
                    model: Subject_1.default,
                    as: 'subject',
                    include: [
                        {
                            model: Teacher_1.default,
                            as: 'teacher',
                            attributes: ['id', 'nom', 'prenom']
                        }
                    ]
                }
            ],
            order: [['day_of_week', 'ASC'], ['start_time', 'ASC']]
        });
        res.json(schedules);
    }
    catch (error) {
        console.error('Error fetching schedules by class:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getSchedulesByClass = getSchedulesByClass;
const createSchedule = async (req, res) => {
    try {
        const { classe_id, subject_id, day_of_week, start_time, end_time } = req.body;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const schedule = await Schedule_1.default.create({
            classe_id,
            subject_id,
            day_of_week,
            start_time,
            end_time,
            school_year_id: schoolYearId
        });
        // Fetch the created schedule with associations
        const createdSchedule = await Schedule_1.default.findByPk(schedule.id, {
            include: [
                {
                    model: Subject_1.default,
                    as: 'subject',
                    include: [
                        {
                            model: Teacher_1.default,
                            as: 'teacher',
                            attributes: ['id', 'nom', 'prenom']
                        }
                    ]
                }
            ]
        });
        res.status(201).json(createdSchedule);
    }
    catch (error) {
        console.error('Error creating schedule:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createSchedule = createSchedule;
const updateSchedule = async (req, res) => {
    try {
        const { id } = req.params;
        const { classe_id, subject_id, day_of_week, start_time, end_time } = req.body;
        const schedule = await Schedule_1.default.findByPk(id);
        if (!schedule) {
            return res.status(404).json({ message: 'Schedule not found' });
        }
        await schedule.update({
            classe_id,
            subject_id,
            day_of_week,
            start_time,
            end_time
        });
        // Fetch updated schedule with associations
        const updatedSchedule = await Schedule_1.default.findByPk(id, {
            include: [
                {
                    model: Subject_1.default,
                    as: 'subject',
                    include: [
                        {
                            model: Teacher_1.default,
                            as: 'teacher',
                            attributes: ['id', 'nom', 'prenom']
                        }
                    ]
                }
            ]
        });
        res.json(updatedSchedule);
    }
    catch (error) {
        console.error('Error updating schedule:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateSchedule = updateSchedule;
const deleteSchedule = async (req, res) => {
    try {
        const { id } = req.params;
        const schedule = await Schedule_1.default.findByPk(id);
        if (!schedule) {
            return res.status(404).json({ message: 'Schedule not found' });
        }
        await schedule.destroy();
        res.json({ message: 'Schedule deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting schedule:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteSchedule = deleteSchedule;
