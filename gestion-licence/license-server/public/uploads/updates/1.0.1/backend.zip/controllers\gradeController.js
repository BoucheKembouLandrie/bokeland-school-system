"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSubjectStats = exports.getSuccessRate = exports.deleteGrade = exports.updateGrade = exports.createGrade = exports.saveGrades = exports.getGradesByClass = exports.getGradesByStudent = exports.getGradeById = exports.getAllGrades = void 0;
const Grade_1 = __importDefault(require("../models/Grade"));
const Student_1 = __importDefault(require("../models/Student"));
const Subject_1 = __importDefault(require("../models/Subject"));
const getAllGrades = async (req, res) => {
    try {
        const grades = await Grade_1.default.findAll({
            include: [
                { model: Student_1.default, as: 'student' },
                { model: Subject_1.default, as: 'subject' }
            ]
        });
        res.json(grades);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllGrades = getAllGrades;
const getGradeById = async (req, res) => {
    try {
        const grade = await Grade_1.default.findByPk(req.params.id, {
            include: [
                { model: Student_1.default, as: 'student' },
                { model: Subject_1.default, as: 'subject' }
            ]
        });
        if (!grade)
            return res.status(404).json({ message: 'Grade not found' });
        res.json(grade);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getGradeById = getGradeById;
const getGradesByStudent = async (req, res) => {
    try {
        const grades = await Grade_1.default.findAll({
            where: { eleve_id: req.params.studentId },
            include: [{ model: Subject_1.default, as: 'subject' }]
        });
        res.json(grades);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getGradesByStudent = getGradesByStudent;
const getGradesByClass = async (req, res) => {
    try {
        const { classId } = req.params;
        const { trimestre } = req.query;
        const whereClause = {};
        if (trimestre) {
            whereClause.trimestre = trimestre;
        }
        // Find all students in the class first
        const students = await Student_1.default.findAll({ where: { classe_id: classId } });
        const studentIds = students.map(s => s.id);
        if (studentIds.length === 0) {
            return res.json([]);
        }
        // Find grades for these students
        const grades = await Grade_1.default.findAll({
            where: {
                eleve_id: studentIds,
                ...whereClause
            },
            include: [
                { model: Student_1.default, as: 'student' },
                { model: Subject_1.default, as: 'subject' }
            ]
        });
        res.json(grades);
    }
    catch (error) {
        console.error('Error fetching class grades:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getGradesByClass = getGradesByClass;
const saveGrades = async (req, res) => {
    try {
        const { grades } = req.body; // Expecting an array of grade objects
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        if (!Array.isArray(grades)) {
            return res.status(400).json({ message: 'Invalid input: grades must be an array' });
        }
        const results = [];
        for (const gradeData of grades) {
            const { eleve_id, matiere_id, trimestre, note } = gradeData;
            // Check if grade exists
            let grade = await Grade_1.default.findOne({
                where: {
                    eleve_id,
                    matiere_id,
                    trimestre,
                    school_year_id: schoolYearId
                }
            });
            if (grade) {
                // Update existing
                grade = await grade.update({ note });
            }
            else {
                // Create new
                grade = await Grade_1.default.create({
                    eleve_id,
                    matiere_id,
                    trimestre,
                    school_year_id: schoolYearId,
                    annee_scolaire: gradeData.annee_scolaire || '2024-2025', // Keep for legacy compatibility
                    note
                });
            }
            results.push(grade);
        }
        res.status(200).json({ message: 'Grades saved successfully', data: results });
    }
    catch (error) {
        console.error('Error saving grades:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.saveGrades = saveGrades;
const createGrade = async (req, res) => {
    try {
        const grade = await Grade_1.default.create(req.body);
        res.status(201).json(grade);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createGrade = createGrade;
const updateGrade = async (req, res) => {
    try {
        const grade = await Grade_1.default.findByPk(req.params.id);
        if (!grade)
            return res.status(404).json({ message: 'Grade not found' });
        await grade.update(req.body);
        res.json(grade);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateGrade = updateGrade;
const deleteGrade = async (req, res) => {
    try {
        const grade = await Grade_1.default.findByPk(req.params.id);
        if (!grade)
            return res.status(404).json({ message: 'Grade not found' });
        await grade.destroy();
        res.json({ message: 'Grade deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteGrade = deleteGrade;
const getSuccessRate = async (req, res) => {
    try {
        const { evaluation, classe_id, eleve_id } = req.query;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        // Build where clause for grades
        const whereClause = { school_year_id: schoolYearId };
        if (evaluation) {
            // Handle multiple evaluations (comma-separated)
            const evaluations = evaluation.split(',');
            if (evaluations.length === 1) {
                whereClause.trimestre = evaluation;
            }
            else {
                const { Op } = require('sequelize');
                whereClause.trimestre = { [Op.in]: evaluations };
            }
        }
        // Get all grades based on filters
        let grades = [];
        if (eleve_id) {
            // Filter by specific student
            grades = await Grade_1.default.findAll({
                where: {
                    eleve_id: Number(eleve_id),
                    ...whereClause
                },
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        else if (classe_id) {
            // Filter by class (handle multiple classes)
            const classeIds = classe_id.split(',').map(id => Number(id));
            const { Op } = require('sequelize');
            const students = await Student_1.default.findAll({
                where: {
                    classe_id: classeIds.length === 1 ? classeIds[0] : { [Op.in]: classeIds },
                    school_year_id: schoolYearId
                }
            });
            const studentIds = students.map(s => s.id);
            if (studentIds.length === 0) {
                return res.json({
                    success: 0,
                    failure: 0,
                    successRate: 0,
                    totalStudents: 0
                });
            }
            grades = await Grade_1.default.findAll({
                where: {
                    eleve_id: studentIds,
                    ...whereClause
                },
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        else {
            // All students
            grades = await Grade_1.default.findAll({
                where: whereClause,
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        // Group grades by student and calculate averages
        const gradesByStudent = {};
        grades.forEach(grade => {
            if (!gradesByStudent[grade.eleve_id]) {
                gradesByStudent[grade.eleve_id] = [];
            }
            gradesByStudent[grade.eleve_id].push(grade);
        });
        // Get all subjects with coefficients
        const subjects = await Subject_1.default.findAll({ where: { school_year_id: schoolYearId } });
        const subjectMap = new Map(subjects.map(s => [s.id, s]));
        // Calculate success/failure
        let successCount = 0;
        let failureCount = 0;
        Object.keys(gradesByStudent).forEach(studentIdStr => {
            const studentGrades = gradesByStudent[Number(studentIdStr)];
            // Calculate weighted average
            let totalPoints = 0;
            let totalCoeffs = 0;
            studentGrades.forEach(grade => {
                const subject = subjectMap.get(grade.matiere_id);
                // Graceful fallback if subject missing (rare but possible across changes)
                const coefficient = subject?.coefficient || 1;
                totalPoints += parseFloat(grade.note) * coefficient;
                totalCoeffs += coefficient;
            });
            const average = totalCoeffs > 0 ? totalPoints / totalCoeffs : 0;
            // Success if average >= 10
            if (average >= 10) {
                successCount++;
            }
            else {
                failureCount++;
            }
        });
        const totalStudents = successCount + failureCount;
        const successRate = totalStudents > 0 ? (successCount / totalStudents) * 100 : 0;
        res.json({
            success: successCount,
            failure: failureCount,
            successRate: parseFloat(successRate.toFixed(2)),
            totalStudents
        });
    }
    catch (error) {
        console.error('Error calculating success rate:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getSuccessRate = getSuccessRate;
const getSubjectStats = async (req, res) => {
    try {
        const { evaluation, classe_id, eleve_id } = req.query;
        const schoolYearId = req.headers['x-school-year-id'];
        console.log('API getSubjectStats params:', { evaluation, classe_id, eleve_id, schoolYearId });
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        // Build where clause for grades
        const whereClause = { school_year_id: schoolYearId };
        if (evaluation) {
            const { Op } = require('sequelize');
            const criteria = [];
            const lowerEv = evaluation.toLowerCase();
            if (lowerEv.includes('1')) {
                criteria.push({ [Op.like]: '%1%' });
                criteria.push({ [Op.like]: '%un%' }); // heuristic
                criteria.push({ [Op.like]: '%premier%' });
            }
            else if (lowerEv.includes('2')) {
                criteria.push({ [Op.like]: '%2%' });
                criteria.push({ [Op.like]: '%deux%' });
                criteria.push({ [Op.like]: '%second%' });
            }
            else if (lowerEv.includes('3')) {
                criteria.push({ [Op.like]: '%3%' });
                criteria.push({ [Op.like]: '%trois%' });
            }
            else {
                // Fallback: match strictly or generic like
                criteria.push({ [Op.like]: `%${evaluation}%` });
            }
            whereClause.trimestre = { [Op.or]: criteria };
        }
        let grades = [];
        // Handle filtering
        if (eleve_id) {
            grades = await Grade_1.default.findAll({
                where: {
                    eleve_id: Number(eleve_id),
                    ...whereClause
                },
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        else if (classe_id) {
            const classeIds = classe_id.split(',').map(id => Number(id));
            const { Op } = require('sequelize');
            // Get students first to ensure we only get grades for students in this class
            const students = await Student_1.default.findAll({
                where: {
                    classe_id: classeIds.length === 1 ? classeIds[0] : { [Op.in]: classeIds },
                    school_year_id: schoolYearId
                }
            });
            const studentIds = students.map(s => s.id);
            if (studentIds.length === 0) {
                return res.json([]);
            }
            grades = await Grade_1.default.findAll({
                where: {
                    eleve_id: studentIds,
                    ...whereClause
                },
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        else {
            // No filters - return global stats
            grades = await Grade_1.default.findAll({
                where: whereClause,
                include: [{ model: Subject_1.default, as: 'subject' }]
            });
        }
        // Group by subject and calculate stats
        const subjectStats = {};
        grades.forEach(grade => {
            if (!grade.subject)
                return;
            const subjectId = grade.matiere_id;
            const note = parseFloat(grade.note);
            if (!subjectStats[subjectId]) {
                subjectStats[subjectId] = {
                    name: grade.subject.nom,
                    total: 0,
                    count: 0,
                    min: note,
                    max: note
                };
            }
            const stat = subjectStats[subjectId];
            stat.total += note;
            stat.count += 1;
            stat.min = Math.min(stat.min, note);
            stat.max = Math.max(stat.max, note);
        });
        // Format result
        const results = Object.values(subjectStats).map(stat => ({
            subject: stat.name,
            average: parseFloat((stat.total / stat.count).toFixed(2)),
            min: stat.min,
            max: stat.max,
            count: stat.count
        }));
        // Sort by average descending
        results.sort((a, b) => b.average - a.average);
        res.json(results);
    }
    catch (error) {
        console.error('Error calculating subject stats:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getSubjectStats = getSubjectStats;
