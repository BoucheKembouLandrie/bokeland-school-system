"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteEvaluation = exports.updateEvaluation = exports.createEvaluation = exports.getAllEvaluations = void 0;
const Evaluation_1 = __importDefault(require("../models/Evaluation"));
const getAllEvaluations = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const evaluations = await Evaluation_1.default.findAll({
            where: { school_year_id: schoolYearId },
            order: [['ordre', 'ASC']]
        });
        res.json(evaluations);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllEvaluations = getAllEvaluations;
const createEvaluation = async (req, res) => {
    try {
        const { nom, date_debut, date_fin } = req.body;
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        // Auto-calculate ordre based on existing evaluations FOR THIS YEAR
        const count = await Evaluation_1.default.count({ where: { school_year_id: schoolYearId } });
        const ordre = count + 1;
        const evaluation = await Evaluation_1.default.create({
            nom,
            date_debut,
            date_fin,
            ordre,
            school_year_id: schoolYearId
        });
        res.status(201).json(evaluation);
    }
    catch (error) {
        console.error('Error creating evaluation:', error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createEvaluation = createEvaluation;
const updateEvaluation = async (req, res) => {
    try {
        const { id } = req.params;
        const { nom, date_debut, date_fin, ordre } = req.body;
        const evaluation = await Evaluation_1.default.findByPk(id);
        if (!evaluation) {
            return res.status(404).json({ message: 'Evaluation not found' });
        }
        await evaluation.update({ nom, date_debut, date_fin, ordre });
        res.json(evaluation);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateEvaluation = updateEvaluation;
const deleteEvaluation = async (req, res) => {
    try {
        const { id } = req.params;
        const evaluation = await Evaluation_1.default.findByPk(id);
        if (!evaluation) {
            return res.status(404).json({ message: 'Evaluation not found' });
        }
        await evaluation.destroy();
        res.json({ message: 'Evaluation deleted successfully' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteEvaluation = deleteEvaluation;
