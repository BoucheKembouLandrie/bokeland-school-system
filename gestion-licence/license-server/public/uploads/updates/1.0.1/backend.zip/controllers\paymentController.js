"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deletePayment = exports.updatePayment = exports.createPayment = exports.getPaymentsByStudent = exports.getPaymentById = exports.getAllPayments = void 0;
const Payment_1 = __importDefault(require("../models/Payment"));
const Student_1 = __importDefault(require("../models/Student"));
const Class_1 = __importDefault(require("../models/Class"));
const SchoolYear_1 = __importDefault(require("../models/SchoolYear"));
const getAllPayments = async (req, res) => {
    try {
        const payments = await Payment_1.default.findAll({ include: [{ model: Student_1.default, as: 'student' }] });
        res.json(payments);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllPayments = getAllPayments;
const getPaymentById = async (req, res) => {
    try {
        const payment = await Payment_1.default.findByPk(req.params.id, { include: [{ model: Student_1.default, as: 'student' }] });
        if (!payment)
            return res.status(404).json({ message: 'Payment not found' });
        res.json(payment);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getPaymentById = getPaymentById;
const getPaymentsByStudent = async (req, res) => {
    try {
        const payments = await Payment_1.default.findAll({ where: { eleve_id: req.params.studentId } });
        res.json(payments);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getPaymentsByStudent = getPaymentsByStudent;
const createPayment = async (req, res) => {
    try {
        const { eleve_id, montant } = req.body;
        // 1. Get Student and their Class to find the Pension
        const student = await Student_1.default.findByPk(eleve_id, {
            include: [{ model: Class_1.default, as: 'class' }]
        });
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }
        // @ts-ignore
        const pension = student.class?.pension || 0;
        // 2. Calculate total previously paid by the student
        const previousPayments = await Payment_1.default.findAll({
            where: { eleve_id }
        });
        const totalPaid = previousPayments.reduce((sum, p) => sum + p.montant, 0);
        // 3. Calculate new remaining balance
        const newTotalPaid = totalPaid + Number(montant);
        const reste = Math.max(0, Number(pension) - newTotalPaid);
        // Determine school_year_id from student's class OR active school year
        // @ts-ignore
        let school_year_id = student.class?.school_year_id;
        if (!school_year_id) {
            const activeYear = await SchoolYear_1.default.findOne({ where: { is_active: true } });
            if (activeYear) {
                school_year_id = activeYear.id;
            }
        }
        // Fallback: If still no ID, try to find the latest
        if (!school_year_id) {
            const latestYear = await SchoolYear_1.default.findOne({ order: [['end_year', 'DESC']] });
            if (latestYear) {
                school_year_id = latestYear.id;
            }
        }
        if (!school_year_id) {
            return res.status(400).json({ message: 'Impossible de déterminer l\'année scolaire (aucune année active trouvée).' });
        }
        // 4. Create the payment with the calculated reste
        const payment = await Payment_1.default.create({
            ...req.body,
            school_year_id,
            reste
        });
        res.status(201).json(payment);
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createPayment = createPayment;
const updatePayment = async (req, res) => {
    try {
        const payment = await Payment_1.default.findByPk(req.params.id);
        if (!payment)
            return res.status(404).json({ message: 'Payment not found' });
        await payment.update(req.body);
        res.json(payment);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updatePayment = updatePayment;
const deletePayment = async (req, res) => {
    try {
        const payment = await Payment_1.default.findByPk(req.params.id);
        if (!payment)
            return res.status(404).json({ message: 'Payment not found' });
        await payment.destroy();
        res.json({ message: 'Payment deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deletePayment = deletePayment;
