"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = __importDefault(require("./config/database"));
const User_1 = __importDefault(require("./models/User"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const resetPassword = async () => {
    try {
        console.log('Resetting admin password...');
        const adminUser = await User_1.default.findOne({ where: { username: 'admin' } });
        if (!adminUser) {
            console.log('Admin user not found!');
            return;
        }
        const hashedPassword = await bcrypt_1.default.hash('admin123', 10);
        await adminUser.update({ password: hashedPassword });
        console.log('Password reset successfully for user: admin');
        console.log('New password: admin123');
    }
    catch (error) {
        console.error('Error resetting password:', error);
    }
    finally {
        await database_1.default.close();
    }
};
resetPassword();
