"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.transferSubjects = exports.deleteSubject = exports.updateSubject = exports.createSubject = exports.getSubjectById = exports.getAllSubjects = void 0;
const Subject_1 = __importDefault(require("../models/Subject"));
const Teacher_1 = __importDefault(require("../models/Teacher"));
const Class_1 = __importDefault(require("../models/Class"));
const SchoolYear_1 = __importDefault(require("../models/SchoolYear"));
const SubjectCategory_1 = __importDefault(require("../models/SubjectCategory"));
const getAllSubjects = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        const classId = req.query.classe_id;
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const whereClause = { school_year_id: schoolYearId };
        if (classId) {
            whereClause.classe_id = classId;
        }
        const subjects = await Subject_1.default.findAll({
            where: whereClause,
            include: [
                { model: Teacher_1.default, as: 'teacher' },
                { model: Class_1.default, as: 'class' },
                { model: SubjectCategory_1.default, as: 'category' }
            ]
        });
        res.json(subjects);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllSubjects = getAllSubjects;
const getSubjectById = async (req, res) => {
    try {
        const subject = await Subject_1.default.findByPk(req.params.id, {
            include: [
                { model: Teacher_1.default, as: 'teacher' },
                { model: Class_1.default, as: 'class' },
                { model: SubjectCategory_1.default, as: 'category' }
            ]
        });
        if (!subject)
            return res.status(404).json({ message: 'Subject not found' });
        res.json(subject);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getSubjectById = getSubjectById;
const createSubject = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        if (!req.body.category_id) {
            return res.status(400).json({ message: 'La catégorie est obligatoire.' });
        }
        const subject = await Subject_1.default.create({
            ...req.body,
            school_year_id: schoolYearId
        });
        res.status(201).json(subject);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.createSubject = createSubject;
const updateSubject = async (req, res) => {
    try {
        const subject = await Subject_1.default.findByPk(req.params.id);
        if (!subject)
            return res.status(404).json({ message: 'Subject not found' });
        if (req.body.category_id === null || req.body.category_id === undefined || req.body.category_id === '') {
            return res.status(400).json({ message: 'La catégorie est obligatoire.' });
        }
        await subject.update(req.body);
        res.json(subject);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateSubject = updateSubject;
const deleteSubject = async (req, res) => {
    try {
        const subject = await Subject_1.default.findByPk(req.params.id);
        if (!subject)
            return res.status(404).json({ message: 'Subject not found' });
        await subject.destroy();
        res.json({ message: 'Subject deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteSubject = deleteSubject;
const transferSubjects = async (req, res) => {
    try {
        const { subjectIds, destYearId } = req.body;
        if (!subjectIds || !Array.isArray(subjectIds) || !destYearId) {
            return res.status(400).json({ message: 'Invalid payload' });
        }
        // Fetch destination year to get its name (needed for creating new classes if they don't exist)
        const destinationYear = await SchoolYear_1.default.findByPk(destYearId);
        if (!destinationYear) {
            return res.status(404).json({ message: 'Destination school year not found' });
        }
        let transferCount = 0;
        let createdClassesCount = 0;
        for (const subjectId of subjectIds) {
            // Find source subject AND its class
            const sourceSubject = await Subject_1.default.findByPk(subjectId, {
                include: [{ model: Class_1.default, as: 'class' }]
            });
            if (sourceSubject && sourceSubject.class) {
                const sourceClass = sourceSubject.class;
                // 1. Try to find matching class in destination year (by exact name/libelle)
                let destClass = await Class_1.default.findOne({
                    where: {
                        libelle: sourceClass.libelle,
                        school_year_id: destYearId
                    }
                });
                // 2. If not found, create it automatically
                if (!destClass) {
                    destClass = await Class_1.default.create({
                        libelle: sourceClass.libelle,
                        niveau: sourceClass.niveau,
                        pension: sourceClass.pension,
                        annee: destinationYear.name,
                        school_year_id: destYearId
                    });
                    createdClassesCount++;
                }
                // 3. Create the subject attached to this resolved class
                await Subject_1.default.create({
                    nom: sourceSubject.nom,
                    coefficient: sourceSubject.coefficient,
                    teacher_id: null, // Teachers must be reassigned manually
                    classe_id: destClass.id,
                    school_year_id: destYearId
                });
                transferCount++;
            }
        }
        res.json({
            message: 'Transfer successful',
            count: transferCount,
            classesCreated: createdClassesCount
        });
    }
    catch (error) {
        console.error('Transfer error:', error);
        res.status(500).json({ message: 'Server error during transfer', error });
    }
};
exports.transferSubjects = transferSubjects;
