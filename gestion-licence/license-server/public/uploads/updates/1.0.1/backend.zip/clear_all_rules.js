"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const ExamRule_1 = __importDefault(require("./models/ExamRule"));
const clearAllRules = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Connected.');
        const yearId = 4;
        const count = await ExamRule_1.default.destroy({ where: { schoolYearId: yearId } });
        console.log(`✅ Deleted ${count} rules for year ID ${yearId}`);
    }
    catch (e) {
        console.error('❌ ERROR:', e.message);
    }
    finally {
        await models_1.sequelize.close();
    }
};
clearAllRules();
