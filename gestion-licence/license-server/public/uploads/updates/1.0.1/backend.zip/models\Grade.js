"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
const Student_1 = __importDefault(require("./Student"));
const Subject_1 = __importDefault(require("./Subject"));
class Grade extends sequelize_1.Model {
}
Grade.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    eleve_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Student_1.default,
            key: 'id',
        },
    },
    matiere_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Subject_1.default,
            key: 'id',
        },
    },
    note: {
        type: sequelize_1.DataTypes.FLOAT,
        allowNull: false,
        validate: {
            min: 0,
            max: 20,
        },
    },
    trimestre: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    annee_scolaire: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    school_year_id: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'school_years',
            key: 'id',
        },
    },
}, {
    sequelize: database_1.default,
    tableName: 'grades',
});
exports.default = Grade;
