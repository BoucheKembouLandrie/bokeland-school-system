"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const models_1 = require("./models");
const SchoolYear_1 = __importDefault(require("./models/SchoolYear"));
const run = async () => {
    try {
        await models_1.sequelize.authenticate();
        const years = await SchoolYear_1.default.findAll();
        console.log(`School Years found: ${years.length}`);
        if (years.length > 0) {
            console.log("Years:", years.map(y => y.toJSON()));
        }
        else {
            console.log("NO SCHOOL YEARS FOUND!");
        }
    }
    catch (error) {
        console.error(error);
    }
    finally {
        await models_1.sequelize.close();
    }
};
run();
