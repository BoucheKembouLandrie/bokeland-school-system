"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("./app"));
const models_1 = require("./models");
const updateService_1 = require("./services/updateService");
const PORT = process.env.PORT || 5006; // Force port to bypass .env
console.log("!!! FORCING PORT 5006 - IGNORE ENV !!!");
console.log("!!! SERVER LOADING NEW CODE - TIMESTAMP " + Date.now() + " !!!");
const startServer = async () => {
    try {
        await models_1.sequelize.authenticate();
        console.log('Database connected successfully.');
        // Sync models - alter:true adds new tables/columns without dropping existing data
        await models_1.sequelize.sync({ alter: true });
        console.log('Models synchronized.');
        // Initialize License Check
        const { checkLicense } = require('./services/licenseService');
        checkLicense(true).then((status) => {
            console.log('--- LICENSE STATUS ---');
            console.log(status);
            console.log('----------------------');
        });
        // Initialize Update Service
        (0, updateService_1.initUpdateService)();
        const server = app_1.default.listen(Number(PORT), '0.0.0.0', () => {
            console.log(`Server is running on port ${PORT}`);
        });
        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.error(`ERROR: Port ${PORT} is already in use! Please stop other running servers.`);
                process.exit(1);
            }
            else {
                console.error('Server error:', err);
            }
        });
    }
    catch (error) {
        console.error('Unable to connect to the database:', error);
    }
};
startServer();
// Forced restart for controller update
// Forced restart for fix check
