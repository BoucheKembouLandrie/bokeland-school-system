"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteAttendance = exports.updateAttendance = exports.createAttendance = exports.getAttendanceByStudent = exports.getAttendanceById = exports.getAllAttendance = void 0;
const Attendance_1 = __importDefault(require("../models/Attendance"));
const Student_1 = __importDefault(require("../models/Student"));
const getAllAttendance = async (req, res) => {
    try {
        const schoolYearId = req.headers['x-school-year-id'];
        const { date, startDate, endDate, limit } = req.query;
        if (!schoolYearId) {
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const whereClause = { school_year_id: schoolYearId };
        // Filter by specific date
        if (date) {
            whereClause.date = date;
        }
        // Filter by date range
        if (startDate && endDate) {
            whereClause.date = {
                [require('sequelize').Op.between]: [startDate, endDate]
            };
        }
        const attendance = await Attendance_1.default.findAll({
            where: whereClause,
            include: [{ model: Student_1.default, as: 'student' }],
            order: [['date', 'DESC']],
            limit: limit ? parseInt(limit) : 1000 // Default limit to prevent overload
        });
        res.json(attendance);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAllAttendance = getAllAttendance;
const getAttendanceById = async (req, res) => {
    try {
        const attendance = await Attendance_1.default.findByPk(req.params.id, { include: [{ model: Student_1.default, as: 'student' }] });
        if (!attendance)
            return res.status(404).json({ message: 'Attendance not found' });
        res.json(attendance);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAttendanceById = getAttendanceById;
const getAttendanceByStudent = async (req, res) => {
    try {
        const attendance = await Attendance_1.default.findAll({ where: { eleve_id: req.params.studentId } });
        res.json(attendance);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.getAttendanceByStudent = getAttendanceByStudent;
const createAttendance = async (req, res) => {
    try {
        console.log("=== CREATE ATTENDANCE REQUEST ===");
        console.log("Headers:", req.headers);
        console.log("Body:", req.body);
        const schoolYearId = req.headers['x-school-year-id'];
        console.log("School Year ID from header:", schoolYearId);
        if (!schoolYearId) {
            console.log("❌ Missing school_year_id header");
            return res.status(400).json({ message: 'School Year ID is required' });
        }
        const payload = {
            ...req.body,
            school_year_id: schoolYearId
        };
        console.log("Creating attendance with payload:", payload);
        const attendance = await Attendance_1.default.create(payload);
        console.log("✅ Attendance created:", attendance.toJSON());
        res.status(201).json(attendance);
    }
    catch (error) {
        console.error("❌ Error creating attendance:", error.message);
        console.error("Stack:", error.stack);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};
exports.createAttendance = createAttendance;
const updateAttendance = async (req, res) => {
    try {
        const attendance = await Attendance_1.default.findByPk(req.params.id);
        if (!attendance)
            return res.status(404).json({ message: 'Attendance not found' });
        await attendance.update(req.body);
        res.json(attendance);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.updateAttendance = updateAttendance;
const deleteAttendance = async (req, res) => {
    try {
        const attendance = await Attendance_1.default.findByPk(req.params.id);
        if (!attendance)
            return res.status(404).json({ message: 'Attendance not found' });
        await attendance.destroy();
        res.json({ message: 'Attendance deleted' });
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
};
exports.deleteAttendance = deleteAttendance;
