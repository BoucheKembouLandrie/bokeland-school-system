"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizeRole = exports.authenticateToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    const logPath = path_1.default.join(__dirname, '../../debug_log.txt');
    if (!token) {
        fs_1.default.appendFileSync(logPath, `[Auth] No token provided for ${req.path}\n`);
        return res.status(401).json({ message: 'Access denied. No token provided.' });
    }
    try {
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET || 'your_jwt_secret');
        req.user = decoded;
        fs_1.default.appendFileSync(logPath, `[Auth] Token verified for user: ${JSON.stringify(decoded)}\n`);
        next();
    }
    catch (error) {
        fs_1.default.appendFileSync(logPath, `[Auth] Invalid token error: ${error.message} (Secret used: ${process.env.JWT_SECRET ? 'Env Var' : 'Fallback'})\n`);
        // Return 401 instead of 403 for invalid token to align with standard auth flow, 
        // though API interceptor handles both.
        return res.status(403).json({ message: 'Invalid token.' });
    }
};
exports.authenticateToken = authenticateToken;
const authorizeRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'Access denied. Insufficient permissions.' });
        }
        next();
    };
};
exports.authorizeRole = authorizeRole;
