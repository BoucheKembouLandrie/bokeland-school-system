"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const database_1 = __importDefault(require("../config/database"));
class ExamRule extends sequelize_1.Model {
}
ExamRule.init({
    id: {
        type: sequelize_1.DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    category: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    min_average: {
        type: sequelize_1.DataTypes.FLOAT,
        allowNull: false,
    },
    max_average: {
        type: sequelize_1.DataTypes.FLOAT,
        allowNull: false,
    },
    min_absence: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    max_absence: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 999,
    },
    status: {
        type: sequelize_1.DataTypes.STRING,
        allowNull: false,
    },
    schoolYearId: {
        type: sequelize_1.DataTypes.INTEGER,
        allowNull: true,
        field: 'school_year_id'
    }
}, {
    sequelize: database_1.default,
    tableName: 'exam_rules',
});
exports.default = ExamRule;
