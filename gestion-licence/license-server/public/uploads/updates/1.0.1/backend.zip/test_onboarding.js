"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
const run = async () => {
    try {
        console.log("Sending onboarding request...");
        const response = await axios_1.default.post('http://localhost:5006/api/onboarding/complete', {
            school_name: "Test School Debug",
            school_year: "2025-2026",
            email: "debug@test.com",
            phone: "123456789",
            country_code: "+237",
            country: "CM",
            address: "Debug Address",
            language: "fr"
        });
        console.log("Success:", response.data);
    }
    catch (error) {
        console.error("Error:", error.response?.data || error.message);
    }
};
run();
